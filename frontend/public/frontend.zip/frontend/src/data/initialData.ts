import { Categoria, AtividadeCadastrada, MetaCategoria, RegistroMensalCategoria, AgendamentoItem } from '../types';

export const CATEGORIAS_INICIAIS: Categoria[] = [
  {
    id: 'cat_corrida',
    nome: 'Corrida',
    unidade_padrao: 'km',
    peso_no_score: 25,
    cor: '#EF4444',
    icone: 'Activity',
    descricao: 'Treinos de corrida (Parque, Esteira, Rua) com métricas de distância',
    criado_em: '2026-01-01T00:00:00Z'
  },
  {
    id: 'cat_futsal',
    nome: 'Futsal / Atividade Física',
    unidade_padrao: 'sessões',
    peso_no_score: 20,
    cor: '#3B82F6',
    icone: 'Flame',
    descricao: 'Partidas e treinos físicos que complementam a resistência aeróbica',
    criado_em: '2026-01-01T00:00:00Z'
  },
  {
    id: 'cat_estudos',
    nome: 'Estudos',
    unidade_padrao: 'minutos',
    peso_no_score: 20,
    cor: '#8B5CF6',
    icone: 'Laptop',
    descricao: 'Dedicação técnica em programação, cloud e arquitetura de software',
    criado_em: '2026-01-01T00:00:00Z'
  },
  {
    id: 'cat_leitura',
    nome: 'Leitura',
    unidade_padrao: 'páginas',
    peso_no_score: 15,
    cor: '#EC4899',
    icone: 'BookOpen',
    descricao: 'Livros de desenvolvimento pessoal, técnicos e não-ficção',
    criado_em: '2026-01-01T00:00:00Z'
  },
  {
    id: 'cat_domesticas',
    nome: 'Tarefas Domésticas',
    unidade_padrao: 'tarefas',
    peso_no_score: 10,
    cor: '#F59E0B',
    icone: 'CheckSquare',
    descricao: 'Manutenção da rotina da casa e organização pessoal',
    criado_em: '2026-01-01T00:00:00Z'
  },
  {
    id: 'cat_lazer',
    nome: 'Lazer',
    unidade_padrao: 'horas',
    peso_no_score: 10,
    cor: '#10B981',
    icone: 'Coffee',
    descricao: 'Descanso de qualidade, convivência e hobbies sem cobrança de meta rígida',
    criado_em: '2026-01-01T00:00:00Z'
  },
  {
    id: 'cat_trabalho',
    nome: 'Trabalho / Carreira',
    unidade_padrao: 'horas',
    peso_no_score: 0, // Peso 0: Não interfere no score de hábitos
    cor: '#64748B',
    icone: 'Briefcase',
    descricao: 'Registro de horas trabalhadas (Empresa, Reuniões) para controle de carga horária',
    criado_em: '2026-01-01T00:00:00Z'
  }
];

export const ATIVIDADES_INICIAIS: AtividadeCadastrada[] = [
  // Corrida
  {
    id: 'ativ_corrida_parque',
    nome: 'Parque',
    categoria_id: 'cat_corrida',
    categoria_nome: 'Corrida',
    recorrente: true,
    unidade: 'km',
    afeta_meta: true,
    progresso_acumulado_ano: 236,
    campos_extras: { tipo_terreno: 'Asfalto / Terra', local: 'Parque Central' }
  },
  {
    id: 'ativ_corrida_esteira',
    nome: 'Esteira',
    categoria_id: 'cat_corrida',
    categoria_nome: 'Corrida',
    recorrente: true,
    unidade: 'km',
    afeta_meta: true,
    progresso_acumulado_ano: 110, // 236 + 110 = 346 km em 2026!
    campos_extras: { local: 'Academia' }
  },

  // Leitura
  {
    id: 'ativ_livro_habitos',
    nome: 'Hábitos Atômicos',
    categoria_id: 'cat_leitura',
    categoria_nome: 'Leitura',
    recorrente: true,
    unidade: 'páginas',
    afeta_meta: true,
    progresso_acumulado_ano: 320,
    campos_extras: { autor: 'James Clear', status: 'Concluído' }
  },
  {
    id: 'ativ_livro_codigo_limpo',
    nome: 'Código Limpo',
    categoria_id: 'cat_leitura',
    categoria_nome: 'Leitura',
    recorrente: true,
    unidade: 'páginas',
    afeta_meta: true,
    progresso_acumulado_ano: 240,
    campos_extras: { autor: 'Robert C. Martin', status: 'Lendo' }
  },

  // Estudos
  {
    id: 'ativ_estudo_python',
    nome: 'Python & Cloud Firestore',
    categoria_id: 'cat_estudos',
    categoria_nome: 'Estudos',
    recorrente: true,
    unidade: 'minutos',
    afeta_meta: true,
    progresso_acumulado_ano: 4800, // 80 horas no ano
    campos_extras: { plataforma: 'Google Cloud & Documentação' }
  },
  {
    id: 'ativ_estudo_frontend',
    nome: 'React & Tailwind UX',
    categoria_id: 'cat_estudos',
    categoria_nome: 'Estudos',
    recorrente: true,
    unidade: 'minutos',
    afeta_meta: true,
    progresso_acumulado_ano: 3600, // 60 horas no ano
    campos_extras: { plataforma: 'Projetos Práticos' }
  },

  // Futsal / Físico
  {
    id: 'ativ_futsal_semanal',
    nome: 'Futsal Terça Noturna',
    categoria_id: 'cat_futsal',
    categoria_nome: 'Futsal / Atividade Física',
    recorrente: true,
    unidade: 'sessões',
    afeta_meta: true,
    progresso_acumulado_ano: 32
  },

  // Domésticas
  {
    id: 'ativ_limpeza_geral',
    nome: 'Organização da Casa & Faxina',
    categoria_id: 'cat_domesticas',
    categoria_nome: 'Tarefas Domésticas',
    recorrente: true,
    unidade: 'tarefas',
    afeta_meta: true,
    progresso_acumulado_ano: 68
  },

  // Lazer
  {
    id: 'ativ_games_descanso',
    nome: 'Cinema & Convivência',
    categoria_id: 'cat_lazer',
    categoria_nome: 'Lazer',
    recorrente: true,
    unidade: 'horas',
    afeta_meta: true,
    progresso_acumulado_ano: 180
  },

  // Trabalho
  {
    id: 'ativ_trabalho_empresa',
    nome: 'Empresa',
    categoria_id: 'cat_trabalho',
    categoria_nome: 'Trabalho / Carreira',
    recorrente: true,
    unidade: 'horas',
    afeta_meta: true,
    progresso_acumulado_ano: 1320,
    campos_extras: { cargo: 'Desenvolvedor' }
  },
  {
    id: 'ativ_trabalho_projetos',
    nome: 'Projetos & Consultoria',
    categoria_id: 'cat_trabalho',
    categoria_nome: 'Trabalho / Carreira',
    recorrente: false,
    unidade: 'horas',
    afeta_meta: true,
    progresso_acumulado_ano: 140
  }
];

export const METAS_MENSAIS_INICIAIS: MetaCategoria[] = [
  {
    id: 'meta_cat_corrida_mensal',
    categoria_id: 'cat_corrida',
    categoria_nome: 'Corrida',
    periodo: 'mensal',
    niveis: {
      minimo: 35,
      ideal: 50,
      excepcional: 70
    },
    unidade: 'km',
    progresso_mes_atual: 42 // Setembro 2026 em andamento
  },
  {
    id: 'meta_cat_futsal_mensal',
    categoria_id: 'cat_futsal',
    categoria_nome: 'Futsal / Atividade Física',
    periodo: 'mensal',
    niveis: {
      minimo: 4,
      ideal: 8,
      excepcional: 12
    },
    unidade: 'sessões',
    progresso_mes_atual: 6
  },
  {
    id: 'meta_cat_estudos_mensal',
    categoria_id: 'cat_estudos',
    categoria_nome: 'Estudos',
    periodo: 'mensal',
    niveis: {
      minimo: 720,  // 12h
      ideal: 1200,  // 20h
      excepcional: 1600 // 26h+
    },
    unidade: 'minutos',
    progresso_mes_atual: 980
  },
  {
    id: 'meta_cat_leitura_mensal',
    categoria_id: 'cat_leitura',
    categoria_nome: 'Leitura',
    periodo: 'mensal',
    niveis: {
      minimo: 150,
      ideal: 300,
      excepcional: 450
    },
    unidade: 'páginas',
    progresso_mes_atual: 220
  },
  {
    id: 'meta_cat_domesticas_mensal',
    categoria_id: 'cat_domesticas',
    categoria_nome: 'Tarefas Domésticas',
    periodo: 'mensal',
    niveis: {
      minimo: 12,
      ideal: 20,
      excepcional: 28
    },
    unidade: 'tarefas',
    progresso_mes_atual: 16
  },
  {
    id: 'meta_cat_lazer_mensal',
    categoria_id: 'cat_lazer',
    categoria_nome: 'Lazer',
    periodo: 'mensal',
    niveis: {
      minimo: 20,
      ideal: 35,
      excepcional: 50
    },
    unidade: 'horas',
    progresso_mes_atual: 28
  },
  {
    id: 'meta_cat_trabalho_mensal',
    categoria_id: 'cat_trabalho',
    categoria_nome: 'Trabalho / Carreira',
    periodo: 'mensal',
    niveis: {
      minimo: 140,
      ideal: 160,
      excepcional: 180
    },
    unidade: 'horas',
    progresso_mes_atual: 152
  }
];

// Histórico consolidado Mês a Mês de 2026 (Janeiro a Setembro)
// Permite análise da menor granularidade (mensal) até semestral e anual com breakdown por atividade!
export const REGISTROS_MENSAIS_2026: RegistroMensalCategoria[] = [
  // JANEIRO (Mês 1)
  { id: 'reg_2026_01_corrida', ano: 2026, mes: 1, categoria_id: 'cat_corrida', categoria_nome: 'Corrida', valor_total: 40, unidade: 'km', atividades_breakdown: { 'Parque': 28, 'Esteira': 12 } },
  { id: 'reg_2026_01_futsal', ano: 2026, mes: 1, categoria_id: 'cat_futsal', categoria_nome: 'Futsal / Atividade Física', valor_total: 7, unidade: 'sessões', atividades_breakdown: { 'Futsal Terça Noturna': 7 } },
  { id: 'reg_2026_01_estudos', ano: 2026, mes: 1, categoria_id: 'cat_estudos', categoria_nome: 'Estudos', valor_total: 1100, unidade: 'minutos', atividades_breakdown: { 'Python & Cloud Firestore': 650, 'React & Tailwind UX': 450 } },
  { id: 'reg_2026_01_leitura', ano: 2026, mes: 1, categoria_id: 'cat_leitura', categoria_nome: 'Leitura', valor_total: 280, unidade: 'páginas', atividades_breakdown: { 'Hábitos Atômicos': 280 } },
  { id: 'reg_2026_01_trabalho', ano: 2026, mes: 1, categoria_id: 'cat_trabalho', categoria_nome: 'Trabalho / Carreira', valor_total: 164, unidade: 'horas', atividades_breakdown: { 'Empresa': 150, 'Projetos & Consultoria': 14 } },

  // FEVEREIRO (Mês 2)
  { id: 'reg_2026_02_corrida', ano: 2026, mes: 2, categoria_id: 'cat_corrida', categoria_nome: 'Corrida', valor_total: 38, unidade: 'km', atividades_breakdown: { 'Parque': 25, 'Esteira': 13 } },
  { id: 'reg_2026_02_futsal', ano: 2026, mes: 2, categoria_id: 'cat_futsal', categoria_nome: 'Futsal / Atividade Física', valor_total: 6, unidade: 'sessões', atividades_breakdown: { 'Futsal Terça Noturna': 6 } },
  { id: 'reg_2026_02_estudos', ano: 2026, mes: 2, categoria_id: 'cat_estudos', categoria_nome: 'Estudos', valor_total: 950, unidade: 'minutos', atividades_breakdown: { 'Python & Cloud Firestore': 500, 'React & Tailwind UX': 450 } },
  { id: 'reg_2026_02_leitura', ano: 2026, mes: 2, categoria_id: 'cat_leitura', categoria_nome: 'Leitura', valor_total: 190, unidade: 'páginas', atividades_breakdown: { 'Hábitos Atômicos': 40, 'Código Limpo': 150 } },
  { id: 'reg_2026_02_trabalho', ano: 2026, mes: 2, categoria_id: 'cat_trabalho', categoria_nome: 'Trabalho / Carreira', valor_total: 152, unidade: 'horas', atividades_breakdown: { 'Empresa': 140, 'Projetos & Consultoria': 12 } },

  // MARÇO (Mês 3)
  { id: 'reg_2026_03_corrida', ano: 2026, mes: 3, categoria_id: 'cat_corrida', categoria_nome: 'Corrida', valor_total: 46, unidade: 'km', atividades_breakdown: { 'Parque': 32, 'Esteira': 14 } },
  { id: 'reg_2026_03_futsal', ano: 2026, mes: 3, categoria_id: 'cat_futsal', categoria_nome: 'Futsal / Atividade Física', valor_total: 8, unidade: 'sessões', atividades_breakdown: { 'Futsal Terça Noturna': 8 } },
  { id: 'reg_2026_03_estudos', ano: 2026, mes: 3, categoria_id: 'cat_estudos', categoria_nome: 'Estudos', valor_total: 1300, unidade: 'minutos', atividades_breakdown: { 'Python & Cloud Firestore': 800, 'React & Tailwind UX': 500 } },
  { id: 'reg_2026_03_leitura', ano: 2026, mes: 3, categoria_id: 'cat_leitura', categoria_nome: 'Leitura', valor_total: 260, unidade: 'páginas', atividades_breakdown: { 'Código Limpo': 90, 'Outros Livros': 170 } },
  { id: 'reg_2026_03_trabalho', ano: 2026, mes: 3, categoria_id: 'cat_trabalho', categoria_nome: 'Trabalho / Carreira', valor_total: 168, unidade: 'horas', atividades_breakdown: { 'Empresa': 152, 'Projetos & Consultoria': 16 } },

  // ABRIL (Mês 4)
  { id: 'reg_2026_04_corrida', ano: 2026, mes: 4, categoria_id: 'cat_corrida', categoria_nome: 'Corrida', valor_total: 44, unidade: 'km', atividades_breakdown: { 'Parque': 30, 'Esteira': 14 } },
  { id: 'reg_2026_04_futsal', ano: 2026, mes: 4, categoria_id: 'cat_futsal', categoria_nome: 'Futsal / Atividade Física', valor_total: 7, unidade: 'sessões', atividades_breakdown: { 'Futsal Terça Noturna': 7 } },
  { id: 'reg_2026_04_estudos', ano: 2026, mes: 4, categoria_id: 'cat_estudos', categoria_nome: 'Estudos', valor_total: 1150, unidade: 'minutos', atividades_breakdown: { 'Python & Cloud Firestore': 650, 'React & Tailwind UX': 500 } },
  { id: 'reg_2026_04_leitura', ano: 2026, mes: 4, categoria_id: 'cat_leitura', categoria_nome: 'Leitura', valor_total: 310, unidade: 'páginas', atividades_breakdown: { 'Outros Livros': 310 } },
  { id: 'reg_2026_04_trabalho', ano: 2026, mes: 4, categoria_id: 'cat_trabalho', categoria_nome: 'Trabalho / Carreira', valor_total: 160, unidade: 'horas', atividades_breakdown: { 'Empresa': 145, 'Projetos & Consultoria': 15 } },

  // MAIO (Mês 5)
  { id: 'reg_2026_05_corrida', ano: 2026, mes: 5, categoria_id: 'cat_corrida', categoria_nome: 'Corrida', valor_total: 48, unidade: 'km', atividades_breakdown: { 'Parque': 34, 'Esteira': 14 } },
  { id: 'reg_2026_05_futsal', ano: 2026, mes: 5, categoria_id: 'cat_futsal', categoria_nome: 'Futsal / Atividade Física', valor_total: 9, unidade: 'sessões', atividades_breakdown: { 'Futsal Terça Noturna': 9 } },
  { id: 'reg_2026_05_estudos', ano: 2026, mes: 5, categoria_id: 'cat_estudos', categoria_nome: 'Estudos', valor_total: 1250, unidade: 'minutos', atividades_breakdown: { 'Python & Cloud Firestore': 700, 'React & Tailwind UX': 550 } },
  { id: 'reg_2026_05_leitura', ano: 2026, mes: 5, categoria_id: 'cat_leitura', categoria_nome: 'Leitura', valor_total: 290, unidade: 'páginas', atividades_breakdown: { 'Outros Livros': 290 } },
  { id: 'reg_2026_05_trabalho', ano: 2026, mes: 5, categoria_id: 'cat_trabalho', categoria_nome: 'Trabalho / Carreira', valor_total: 165, unidade: 'horas', atividades_breakdown: { 'Empresa': 148, 'Projetos & Consultoria': 17 } },

  // JUNHO (Mês 6 - Fim S1)
  { id: 'reg_2026_06_corrida', ano: 2026, mes: 6, categoria_id: 'cat_corrida', categoria_nome: 'Corrida', valor_total: 42, unidade: 'km', atividades_breakdown: { 'Parque': 29, 'Esteira': 13 } },
  { id: 'reg_2026_06_futsal', ano: 2026, mes: 6, categoria_id: 'cat_futsal', categoria_nome: 'Futsal / Atividade Física', valor_total: 8, unidade: 'sessões', atividades_breakdown: { 'Futsal Terça Noturna': 8 } },
  { id: 'reg_2026_06_estudos', ano: 2026, mes: 6, categoria_id: 'cat_estudos', categoria_nome: 'Estudos', valor_total: 1100, unidade: 'minutos', atividades_breakdown: { 'Python & Cloud Firestore': 600, 'React & Tailwind UX': 500 } },
  { id: 'reg_2026_06_leitura', ano: 2026, mes: 6, categoria_id: 'cat_leitura', categoria_nome: 'Leitura', valor_total: 250, unidade: 'páginas', atividades_breakdown: { 'Outros Livros': 250 } },
  { id: 'reg_2026_06_trabalho', ano: 2026, mes: 6, categoria_id: 'cat_trabalho', categoria_nome: 'Trabalho / Carreira', valor_total: 162, unidade: 'horas', atividades_breakdown: { 'Empresa': 146, 'Projetos & Consultoria': 16 } },

  // JULHO (Mês 7)
  { id: 'reg_2026_07_corrida', ano: 2026, mes: 7, categoria_id: 'cat_corrida', categoria_nome: 'Corrida', valor_total: 44, unidade: 'km', atividades_breakdown: { 'Parque': 30, 'Esteira': 14 } },
  { id: 'reg_2026_07_futsal', ano: 2026, mes: 7, categoria_id: 'cat_futsal', categoria_nome: 'Futsal / Atividade Física', valor_total: 8, unidade: 'sessões', atividades_breakdown: { 'Futsal Terça Noturna': 8 } },
  { id: 'reg_2026_07_estudos', ano: 2026, mes: 7, categoria_id: 'cat_estudos', categoria_nome: 'Estudos', valor_total: 1200, unidade: 'minutos', atividades_breakdown: { 'Python & Cloud Firestore': 700, 'React & Tailwind UX': 500 } },
  { id: 'reg_2026_07_leitura', ano: 2026, mes: 7, categoria_id: 'cat_leitura', categoria_nome: 'Leitura', valor_total: 270, unidade: 'páginas', atividades_breakdown: { 'Outros Livros': 270 } },
  { id: 'reg_2026_07_trabalho', ano: 2026, mes: 7, categoria_id: 'cat_trabalho', categoria_nome: 'Trabalho / Carreira', valor_total: 166, unidade: 'horas', atividades_breakdown: { 'Empresa': 150, 'Projetos & Consultoria': 16 } },

  // AGOSTO (Mês 8 - MÊS PASSADO)
  { id: 'reg_2026_08_corrida', ano: 2026, mes: 8, categoria_id: 'cat_corrida', categoria_nome: 'Corrida', valor_total: 50, unidade: 'km', atividades_breakdown: { 'Parque': 34, 'Esteira': 16 } },
  { id: 'reg_2026_08_futsal', ano: 2026, mes: 8, categoria_id: 'cat_futsal', categoria_nome: 'Futsal / Atividade Física', valor_total: 9, unidade: 'sessões', atividades_breakdown: { 'Futsal Terça Noturna': 9 } },
  { id: 'reg_2026_08_estudos', ano: 2026, mes: 8, categoria_id: 'cat_estudos', categoria_nome: 'Estudos', valor_total: 1350, unidade: 'minutos', atividades_breakdown: { 'Python & Cloud Firestore': 800, 'React & Tailwind UX': 550 } },
  { id: 'reg_2026_08_leitura', ano: 2026, mes: 8, categoria_id: 'cat_leitura', categoria_nome: 'Leitura', valor_total: 330, unidade: 'páginas', atividades_breakdown: { 'Outros Livros': 330 } },
  { id: 'reg_2026_08_trabalho', ano: 2026, mes: 8, categoria_id: 'cat_trabalho', categoria_nome: 'Trabalho / Carreira', valor_total: 170, unidade: 'horas', atividades_breakdown: { 'Empresa': 154, 'Projetos & Consultoria': 16 } },

  // SETEMBRO (Mês 9 - MÊS ATUAL / TEMPO REAL)
  // Total acumulado em 2026 até agora: 40+38+46+44+48+42+44+50 + 42 (Setembro) = 346 km!
  { id: 'reg_2026_09_corrida', ano: 2026, mes: 9, categoria_id: 'cat_corrida', categoria_nome: 'Corrida', valor_total: 42, unidade: 'km', atividades_breakdown: { 'Parque': 28, 'Esteira': 14 } },
  { id: 'reg_2026_09_futsal', ano: 2026, mes: 9, categoria_id: 'cat_futsal', categoria_nome: 'Futsal / Atividade Física', valor_total: 6, unidade: 'sessões', atividades_breakdown: { 'Futsal Terça Noturna': 6 } },
  { id: 'reg_2026_09_estudos', ano: 2026, mes: 9, categoria_id: 'cat_estudos', categoria_nome: 'Estudos', valor_total: 980, unidade: 'minutos', atividades_breakdown: { 'Python & Cloud Firestore': 580, 'React & Tailwind UX': 400 } },
  { id: 'reg_2026_09_leitura', ano: 2026, mes: 9, categoria_id: 'cat_leitura', categoria_nome: 'Leitura', valor_total: 220, unidade: 'páginas', atividades_breakdown: { 'Código Limpo': 220 } },
  { id: 'reg_2026_09_trabalho', ano: 2026, mes: 9, categoria_id: 'cat_trabalho', categoria_nome: 'Trabalho / Carreira', valor_total: 152, unidade: 'horas', atividades_breakdown: { 'Empresa': 136, 'Projetos & Consultoria': 16 } }
];

export const AGENDAMENTOS_INICIAIS: AgendamentoItem[] = [
  {
    id: 'ag_rotina_01',
    tipo: 'rotina',
    titulo: 'Corrida no Parque (5km)',
    data: '2026-09-07',
    hora_inicio: '06:30',
    hora_fim: '07:15',
    duracao_minutos: 45,
    concluido: true,
    atividade_id: 'ativ_corrida_parque',
    atividade_nome: 'Parque',
    categoria_id: 'cat_corrida',
    categoria_nome: 'Corrida',
    cor: '#EF4444'
  },
  {
    id: 'ag_rotina_02',
    tipo: 'rotina',
    titulo: 'Trabalho Empresa (Sprint Review & Refactor)',
    data: '2026-09-07',
    hora_inicio: '09:00',
    hora_fim: '18:00',
    duracao_minutos: 540,
    concluido: false,
    atividade_id: 'ativ_trabalho_empresa',
    atividade_nome: 'Empresa',
    categoria_id: 'cat_trabalho',
    categoria_nome: 'Trabalho / Carreira',
    cor: '#64748B'
  },
  {
    id: 'ag_rotina_03',
    tipo: 'rotina',
    titulo: 'Leitura: Código Limpo',
    data: '2026-09-07',
    hora_inicio: '21:30',
    hora_fim: '22:15',
    duracao_minutos: 45,
    concluido: false,
    atividade_id: 'ativ_livro_codigo_limpo',
    atividade_nome: 'Código Limpo',
    categoria_id: 'cat_leitura',
    categoria_nome: 'Leitura',
    cor: '#EC4899'
  },
  // Compromisso pontual sem categoria (lembrete)
  {
    id: 'ag_pontual_01',
    tipo: 'pontual',
    titulo: 'Dentista - Revisão Semestral',
    data: '2026-09-07',
    hora_inicio: '14:30',
    concluido: false,
    descricao: 'Consultório Dr. Marcelo - Levar exames'
  },
  {
    id: 'ag_pontual_02',
    tipo: 'pontual',
    titulo: 'Comprar bateria do carro',
    data: '2026-09-08',
    hora_inicio: '11:00',
    concluido: false,
    descricao: 'Modelo CR2032'
  }
];
