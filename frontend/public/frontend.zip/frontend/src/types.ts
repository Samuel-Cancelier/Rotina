export interface Categoria {
  id: string;
  nome: string;
  unidade_padrao: string;
  peso_no_score: number; // Ex: 25 (soma com score deve fechar em 100%, Trabalho = 0)
  cor: string;
  icone: string;
  descricao?: string;
  criado_em?: string;
}

export interface AtividadeCadastrada {
  id: string;
  nome: string;
  categoria_id: string;
  categoria_nome: string;
  recorrente: boolean;
  unidade: string;
  afeta_meta: boolean;
  progresso_acumulado_ano?: number; // Total acumulado em 2026 nesta atividade
  campos_extras?: Record<string, any>;
  criado_em?: string;
}

export interface MetaCategoria {
  id: string;
  categoria_id: string;
  categoria_nome: string;
  periodo: 'mensal' | 'anual';
  niveis: {
    minimo: number;       // Sucesso parcial (~60%)
    ideal: number;        // 100% da meta
    excepcional: number;  // Superação (até 120%)
  };
  unidade: string;
  progresso_mes_atual: number;
}

export interface RegistroMensalCategoria {
  id: string;
  ano: number;
  mes: number; // 1 a 12
  categoria_id: string;
  categoria_nome: string;
  valor_total: number;
  unidade: string;
  atividades_breakdown: Record<string, number>; // ex: { "Parque": 45, "Esteira": 15 }
}

export type TipoAgendamento = 'rotina' | 'pontual' | 'google_agenda';

export interface AgendamentoItem {
  id: string;
  tipo: TipoAgendamento;
  titulo: string;
  data: string; // YYYY-MM-DD
  hora_inicio?: string; // HH:mm
  hora_fim?: string;    // HH:mm
  duracao_minutos?: number;
  concluido?: boolean;
  
  // Para rotinas com categoria
  atividade_id?: string;
  atividade_nome?: string;
  categoria_id?: string;
  categoria_nome?: string;
  cor?: string;

  // Para lembretes pontuais sem categoria
  descricao?: string;
  tag_livre?: string;

  // Para Google Agenda
  google_event_id?: string;
  link_reuniao?: string;
  local?: string;
  calendario_nome?: string;
}
