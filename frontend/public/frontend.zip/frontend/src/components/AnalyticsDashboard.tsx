import React, { useState } from 'react';
import { Categoria, AtividadeCadastrada, MetaCategoria, RegistroMensalCategoria } from '../types';
import {
  Calendar,
  TrendingUp,
  Award,
  BarChart3,
  Clock,
  Layers,
  ChevronRight,
  Filter,
  CheckCircle2,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
  PieChart as PieIcon,
  HelpCircle,
  Plus
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Legend
} from 'recharts';

interface AnalyticsDashboardProps {
  categorias: Categoria[];
  atividades: AtividadeCadastrada[];
  metas: MetaCategoria[];
  registrosMensais: RegistroMensalCategoria[];
  onAddRegistroMensal?: (registro: RegistroMensalCategoria) => void;
}

type PeriodoVisualizacao = 'tempo_real' | 'mes_passado' | 'semestral_1' | 'semestral_2' | 'anual_2026';

const MESES_NOMES = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
];

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  categorias,
  atividades,
  metas,
  registrosMensais
}) => {
  const [periodo, setPeriodo] = useState<PeriodoVisualizacao>('tempo_real');
  const [categoriaFoco, setCategoriaFoco] = useState<string>('cat_corrida');
  const [showAddModal, setShowAddModal] = useState(false);

  // Mês atual é Setembro (9), mês passado é Agosto (8)
  const mesAtualNum = 9;
  const mesPassadoNum = 8;

  // Filtragem dos registros pelo período selecionado
  const registrosFiltrados = registrosMensais.filter((r) => {
    if (periodo === 'tempo_real') return r.ano === 2026 && r.mes === mesAtualNum;
    if (periodo === 'mes_passado') return r.ano === 2026 && r.mes === mesPassadoNum;
    if (periodo === 'semestral_1') return r.ano === 2026 && r.mes >= 1 && r.mes <= 6;
    if (periodo === 'semestral_2') return r.ano === 2026 && r.mes >= 7 && r.mes <= 12;
    if (periodo === 'anual_2026') return r.ano === 2026;
    return true;
  });

  // Cálculo consolidado por categoria no período selecionado
  const consolidadosPorCategoria = categorias.map((cat) => {
    const registrosDaCat = registrosFiltrados.filter((r) => r.categoria_id === cat.id);
    const totalPeriodo = registrosDaCat.reduce((acc, curr) => acc + curr.valor_total, 0);

    // Acumulador de breakdown por atividade dentro da categoria
    const breakdownAtividades: Record<string, number> = {};
    registrosDaCat.forEach((r) => {
      if (r.atividades_breakdown) {
        Object.entries(r.atividades_breakdown).forEach(([ativNome, val]) => {
          breakdownAtividades[ativNome] = (breakdownAtividades[ativNome] || 0) + (Number(val) || 0);
        });
      }
    });

    // Se for mensal, compara com a meta mensal correspondente
    const metaCat = metas.find((m) => m.categoria_id === cat.id);
    const metaIdeal = metaCat ? metaCat.niveis.ideal : 0;
    const multiplicadorPeriodo =
      periodo === 'anual_2026' ? 12 : periodo.startsWith('semestral') ? 6 : 1;
    const metaAjustada = metaIdeal * multiplicadorPeriodo;

    // Cálculo do atingimento
    const pctAtingido =
      metaAjustada > 0 ? Math.round((totalPeriodo / metaAjustada) * 100) : 100;

    return {
      categoria: cat,
      total: totalPeriodo,
      unidade: cat.unidade_padrao,
      metaAjustada,
      pctAtingido,
      breakdownAtividades
    };
  });

  // Cálculo do Score Geral Ponderado no período selecionado
  let somaScore = 0;
  let somaPesos = 0;
  consolidadosPorCategoria.forEach((item) => {
    const peso = item.categoria.peso_no_score;
    if (peso > 0) {
      // Regra de 3 níveis: Mínimo (~60%), Ideal (100%), Excepcional (até 120%)
      const scoreIndividual = Math.min(120, item.pctAtingido);
      somaScore += scoreIndividual * peso;
      somaPesos += peso;
    }
  });
  const scoreGeralPeriodo = somaPesos > 0 ? Math.round(somaScore / somaPesos) : 0;

  // Categoria em foco para exibição detalhada de Parque vs Esteira etc.
  const dadosCatFoco = consolidadosPorCategoria.find((c) => c.categoria.id === categoriaFoco);

  // Totais anuais gerais (ex: 346 km corridos em 2026)
  const totalCorridaAno = registrosMensais
    .filter((r) => r.categoria_id === 'cat_corrida')
    .reduce((acc, curr) => acc + curr.valor_total, 0);

  const totalTrabalhoAno = registrosMensais
    .filter((r) => r.categoria_id === 'cat_trabalho')
    .reduce((acc, curr) => acc + curr.valor_total, 0);

  const totalLeituraAno = registrosMensais
    .filter((r) => r.categoria_id === 'cat_leitura')
    .reduce((acc, curr) => acc + curr.valor_total, 0);

  // Preparação de dados para o gráfico de evolução temporal (Jan a Set)
  const dadosGraficoMensal = Array.from({ length: 9 }, (_, i) => {
    const mesIndex = i + 1;
    const ponto: Record<string, any> = {
      mes: MESES_NOMES[i].substring(0, 3)
    };

    categorias.forEach((c) => {
      const reg = registrosMensais.find((r) => r.ano === 2026 && r.mes === mesIndex && r.categoria_id === c.id);
      ponto[c.nome] = reg ? reg.valor_total : 0;
    });

    return ponto;
  });

  return (
    <div className="space-y-6" id="analytics-dashboard-root">
      {/* Barra de Filtro de Período Temporal */}
      <div className="bg-[#111] rounded-2xl border border-[#222] p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[11px] font-mono uppercase tracking-wider text-amber-400/80 font-bold block">
            Painel Analítico de Metas & Histórico
          </span>
          <h2 className="text-xl font-serif italic text-white mt-0.5">
            Evolução Temporal com Granularidade Mensal
          </h2>
        </div>

        {/* Botões do Seletor de Período */}
        <div className="inline-flex p-1 bg-[#181818] border border-[#2a2a2a] rounded-xl overflow-x-auto no-scrollbar">
          <button
            id="btn-periodo-tempo-real"
            onClick={() => setPeriodo('tempo_real')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
              periodo === 'tempo_real'
                ? 'bg-amber-500 text-black font-semibold shadow-xs'
                : 'text-[#888] hover:text-white'
            }`}
          >
            🟢 Mês Atual (Setembro)
          </button>
          <button
            id="btn-periodo-mes-passado"
            onClick={() => setPeriodo('mes_passado')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
              periodo === 'mes_passado'
                ? 'bg-amber-500 text-black font-semibold shadow-xs'
                : 'text-[#888] hover:text-white'
            }`}
          >
            ⏮️ Mês Passado (Agosto)
          </button>
          <button
            id="btn-periodo-semestral-1"
            onClick={() => setPeriodo('semestral_1')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
              periodo === 'semestral_1'
                ? 'bg-amber-500 text-black font-semibold shadow-xs'
                : 'text-[#888] hover:text-white'
            }`}
          >
            📊 1º Semestre (Jan-Jun)
          </button>
          <button
            id="btn-periodo-semestral-2"
            onClick={() => setPeriodo('semestral_2')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
              periodo === 'semestral_2'
                ? 'bg-amber-500 text-black font-semibold shadow-xs'
                : 'text-[#888] hover:text-white'
            }`}
          >
            📊 2º Semestre (Jul-Dez)
          </button>
          <button
            id="btn-periodo-anual-2026"
            onClick={() => setPeriodo('anual_2026')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
              periodo === 'anual_2026'
                ? 'bg-amber-500 text-black font-semibold shadow-xs'
                : 'text-[#888] hover:text-white'
            }`}
          >
            🏆 Anual (Ano 2026 Completo)
          </button>
        </div>
      </div>

      {/* Cards de Valores Gerais Acumulados em 2026 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Corrida no Ano */}
        <div className="bg-[#121212] border border-[#222] rounded-2xl p-4.5 relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-[#888]">
            <span className="font-mono text-[11px] uppercase tracking-wider">Acumulado 2026</span>
            <span className="w-2 h-2 rounded-full bg-red-500"></span>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-black text-white font-mono">{totalCorridaAno}</span>
            <span className="text-sm text-red-400 font-medium">km corridos</span>
          </div>
          <p className="text-[11px] text-[#777] mt-1">
            Parque: 236 km • Esteira: 110 km
          </p>
        </div>

        {/* Trabalho no Ano (Sem Peso) */}
        <div className="bg-[#121212] border border-[#222] rounded-2xl p-4.5 relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-[#888]">
            <span className="font-mono text-[11px] uppercase tracking-wider">Carga Horária 2026</span>
            <span className="w-2 h-2 rounded-full bg-slate-400"></span>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-black text-white font-mono">{totalTrabalhoAno}</span>
            <span className="text-sm text-slate-300 font-medium">horas trabalhadas</span>
          </div>
          <p className="text-[11px] text-[#777] mt-1">
            Empresa: 1.320h • Projetos: 140h (Peso 0)
          </p>
        </div>

        {/* Leitura no Ano */}
        <div className="bg-[#121212] border border-[#222] rounded-2xl p-4.5 relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-[#888]">
            <span className="font-mono text-[11px] uppercase tracking-wider">Leitura 2026</span>
            <span className="w-2 h-2 rounded-full bg-pink-500"></span>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-black text-white font-mono">{totalLeituraAno}</span>
            <span className="text-sm text-pink-400 font-medium">páginas lidas</span>
          </div>
          <p className="text-[11px] text-[#777] mt-1">
            2 livros concluídos, 1 em andamento
          </p>
        </div>

        {/* Score Ponderado do Período */}
        <div className="bg-linear-to-br from-[#1a1714] to-[#121212] border border-amber-500/30 rounded-2xl p-4.5 relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-amber-300/80">
            <span className="font-mono text-[11px] uppercase tracking-wider">Score Ponderado</span>
            <Award className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-black text-amber-400 font-mono">{scoreGeralPeriodo}</span>
            <span className="text-xs text-amber-200/70 font-mono">/100 ({periodo === 'tempo_real' ? 'Setembro' : periodo === 'mes_passado' ? 'Agosto' : 'Período'})</span>
          </div>
          <p className="text-[11px] text-[#999] mt-1">
            {scoreGeralPeriodo >= 90 ? '🌟 Nível Excepcional' : scoreGeralPeriodo >= 75 ? '✅ Meta Ideal Batida' : '⚡ No Ritmo'}
          </p>
        </div>
      </div>

      {/* Grid Principal: Detalhamento por Categoria e Detalhe da Atividade (Parque vs Esteira) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Coluna 1 & 2: Grid com todas as categorias no período */}
        <div className="lg:col-span-2 bg-[#0d0d0d] border border-[#222] rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Layers className="w-4 h-4 text-amber-400" />
              <h3 className="text-base font-serif italic text-white">
                Metas & Execuções no Período Selecionado
              </h3>
            </div>
            <span className="text-[11px] font-mono text-[#777]">
              Clique no item para ver a divisão de atividades
            </span>
          </div>

          <div className="space-y-3">
            {consolidadosPorCategoria.map((item) => {
              const isSelected = item.categoria.id === categoriaFoco;
              const ehTrabalho = item.categoria.peso_no_score === 0;

              return (
                <div
                  key={item.categoria.id}
                  id={`cat-card-${item.categoria.id}`}
                  onClick={() => setCategoriaFoco(item.categoria.id)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#181818] border-amber-500/50 shadow-sm'
                      : 'bg-[#121212] border-[#222] hover:border-[#333]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2.5">
                      <span
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: item.categoria.cor }}
                      />
                      <span className="font-semibold text-white text-sm">
                        {item.categoria.nome}
                      </span>
                      {ehTrabalho ? (
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#222] text-[#888] border border-[#333]">
                          Informativo (0% no Score)
                        </span>
                      ) : (
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20">
                          Peso: {item.categoria.peso_no_score}%
                        </span>
                      )}
                    </div>

                    <div className="text-right">
                      <span className="font-mono text-base font-bold text-white">
                        {item.total}{' '}
                        <span className="text-xs font-normal text-[#888]">{item.unidade}</span>
                      </span>
                      <span className="text-[11px] text-[#666] ml-2 font-mono">
                        (Ref: {item.metaAjustada} {item.unidade})
                      </span>
                    </div>
                  </div>

                  {/* Barra de Progresso */}
                  <div className="w-full bg-[#202020] h-2 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: `${Math.min(100, item.pctAtingido)}%`,
                        backgroundColor: item.categoria.cor
                      }}
                    />
                  </div>

                  <div className="flex items-center justify-between mt-2 text-xs text-[#777]">
                    <span>Atingimento da Meta: <strong className="text-[#bbb]">{item.pctAtingido}%</strong></span>
                    <span className="text-[11px] font-mono text-amber-400 flex items-center gap-1">
                      Ver Atividades Específicas <ChevronRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Coluna 3: Caixa de Detalhamento por Atividade Específica (Parque vs Esteira) */}
        <div className="bg-[#0d0d0d] border border-[#222] rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-amber-400" />
              <h3 className="text-sm font-semibold text-white uppercase tracking-wider font-mono">
                Detalhamento de Atividade
              </h3>
            </div>
            {dadosCatFoco && (
              <span
                className="text-[11px] font-mono px-2 py-0.5 rounded text-white font-medium"
                style={{ backgroundColor: `${dadosCatFoco.categoria.cor}33`, color: dadosCatFoco.categoria.cor }}
              >
                {dadosCatFoco.categoria.nome}
              </span>
            )}
          </div>

          {dadosCatFoco && (
            <div className="space-y-4">
              <div className="bg-[#141414] p-3.5 rounded-xl border border-[#252525]">
                <span className="text-xs text-[#888] block">Total nesta Categoria ({periodo.replace('_', ' ')}):</span>
                <span className="text-2xl font-black font-mono text-white mt-1 block">
                  {dadosCatFoco.total} <span className="text-xs font-normal text-[#888]">{dadosCatFoco.unidade}</span>
                </span>
              </div>

              <div>
                <span className="text-xs text-[#888] font-mono uppercase tracking-wider block mb-2.5">
                  Distribuição por Atividade Cadastrada:
                </span>

                {Object.keys(dadosCatFoco.breakdownAtividades).length === 0 ? (
                  <p className="text-xs text-[#666] italic">
                    Nenhum lançamento detalhado registrado nesta categoria para este período.
                  </p>
                ) : (
                  <div className="space-y-2.5">
                    {Object.entries(dadosCatFoco.breakdownAtividades).map(([ativNome, rawQtd]) => {
                      const qtd = Number(rawQtd) || 0;
                      const pct = dadosCatFoco.total > 0 ? Math.round((qtd / dadosCatFoco.total) * 100) : 0;
                      return (
                        <div key={ativNome} className="bg-[#121212] p-3 rounded-xl border border-[#222]">
                          <div className="flex items-center justify-between text-xs mb-1.5">
                            <span className="font-semibold text-[#eee]">{ativNome}</span>
                            <span className="font-mono text-white font-bold">
                              {qtd} {dadosCatFoco.unidade} ({pct}%)
                            </span>
                          </div>
                          <div className="w-full bg-[#202020] h-1.5 rounded-full overflow-hidden">
                            <div
                              className="h-full rounded-full"
                              style={{
                                width: `${pct}%`,
                                backgroundColor: dadosCatFoco.categoria.cor
                              }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Informação didática sobre comando Telegram */}
              <div className="bg-[#161616] p-3 rounded-xl border border-[#282828] text-xs text-[#888] space-y-1">
                <span className="font-semibold text-amber-300 block">Dica do Telegram:</span>
                <p className="text-[11px] leading-relaxed">
                  Para direcionar exatamente para uma atividade específica, use:
                  <code className="block mt-1 bg-black/50 p-1.5 rounded text-amber-200 font-mono text-[10px]">
                    /feito {dadosCatFoco.categoria.nome.toLowerCase().split(' ')[0]} [Atividade] [Qtd]
                  </code>
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Gráfico de Evolução Mensal Consolidada (Jan a Setembro de 2026) */}
      <div className="bg-[#0d0d0d] border border-[#222] rounded-2xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-amber-400" />
              <h3 className="text-base font-serif italic text-white">
                Evolução Mensal em 2026 (Menor Granularidade: Mês a Mês)
              </h3>
            </div>
            <p className="text-xs text-[#777] mt-0.5">
              Comparativo das 6 categorias com metas e do Trabalho (0% de peso).
            </p>
          </div>
          <span className="text-[11px] font-mono px-2.5 py-1 rounded bg-[#181818] border border-[#2a2a2a] text-amber-400">
            Total Corrida 2026: {totalCorridaAno} km
          </span>
        </div>

        <div className="h-72 w-full pt-4">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={dadosGraficoMensal} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#222" />
              <XAxis dataKey="mes" stroke="#666" fontSize={11} tickLine={false} />
              <YAxis stroke="#666" fontSize={11} tickLine={false} />
              <Tooltip
                contentStyle={{ backgroundColor: '#141414', borderColor: '#333', borderRadius: '8px', fontSize: '12px' }}
                itemStyle={{ color: '#eee' }}
              />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
              <Bar dataKey="Corrida" fill="#EF4444" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Leitura" fill="#EC4899" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Futsal / Atividade Física" fill="#3B82F6" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Trabalho / Carreira" fill="#64748B" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
