import React, { useState } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Clock,
  Plus,
  CheckCircle2,
  Circle,
  ExternalLink,
  Sparkles,
  CalendarPlus,
  Tag,
  Trash2,
  Video,
  MapPin,
  RefreshCw,
  BookOpen,
  FolderTree,
  Terminal,
  Layers,
  HelpCircle,
  AlertCircle
} from 'lucide-react';
import { AgendamentoItem, AtividadeCadastrada, Categoria, TipoAgendamento } from '../types';

interface CalendarViewProps {
  agendamentos: AgendamentoItem[];
  atividades: AtividadeCadastrada[];
  categorias: Categoria[];
  onAddAgendamento: (item: Omit<AgendamentoItem, 'id'>) => void;
  onToggleConcluido: (id: string) => void;
  onDeleteAgendamento: (id: string) => void;
  onSyncGoogleCalendar?: () => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  agendamentos,
  atividades,
  categorias,
  onAddAgendamento,
  onToggleConcluido,
  onDeleteAgendamento,
  onSyncGoogleCalendar
}) => {
  // Current view state - Default to September 2026
  const [currentYear, setCurrentYear] = useState<number>(2026);
  const [currentMonth, setCurrentMonth] = useState<number>(8); // 8 is September (0-indexed)
  const [selectedDate, setSelectedDate] = useState<string>('2026-09-07');
  const [filtroTipo, setFiltroTipo] = useState<'todos' | TipoAgendamento>('todos');

  // Modals
  const [modalRotinaOpen, setModalRotinaOpen] = useState(false);
  const [modalPontualOpen, setModalPontualOpen] = useState(false);
  const [modalGoogleSyncOpen, setModalGoogleSyncOpen] = useState(false);
  const [showGuiaPassoAPasso, setShowGuiaPassoAPasso] = useState(false);

  // Form states for Routine Scheduling
  const [formRotinaAtividadeId, setFormRotinaAtividadeId] = useState<string>(atividades[0]?.id || '');
  const [formRotinaData, setFormRotinaData] = useState<string>('2026-09-07');
  const [formRotinaHoraInicio, setFormRotinaHoraInicio] = useState<string>('08:00');
  const [formRotinaHoraFim, setFormRotinaHoraFim] = useState<string>('09:00');

  // Form states for Punctual Activity (NO CATEGORY REQUIRED)
  const [formPontualTitulo, setFormPontualTitulo] = useState<string>('');
  const [formPontualData, setFormPontualData] = useState<string>('2026-09-07');
  const [formPontualHoraInicio, setFormPontualHoraInicio] = useState<string>('14:00');
  const [formPontualHoraFim, setFormPontualHoraFim] = useState<string>('15:00');
  const [formPontualTag, setFormPontualTag] = useState<string>('Pessoal');
  const [formPontualDescricao, setFormPontualDescricao] = useState<string>('');

  // Sync state
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);

  // Month navigation
  const prevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear((y) => y - 1);
    } else {
      setCurrentMonth((m) => m - 1);
    }
  };

  const nextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear((y) => y + 1);
    } else {
      setCurrentMonth((m) => m + 1);
    }
  };

  const setHoje = () => {
    setCurrentYear(2026);
    setCurrentMonth(8);
    setSelectedDate('2026-09-07');
  };

  // Month metadata
  const nomesMeses = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  // Calendar days calculation
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
  // Adjust so Monday is first (0: Dom -> 6, 1: Seg -> 0, etc.)
  const startingOffset = (firstDayOfMonth + 6) % 7;
  const daysInCurrentMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

  // Filter items
  const filteredItems = agendamentos.filter((item) => {
    if (filtroTipo === 'todos') return true;
    return item.tipo === filtroTipo;
  });

  // Items for the selected day
  const selectedDayItems = filteredItems
    .filter((item) => item.data === selectedDate)
    .sort((a, b) => (a.hora_inicio || '00:00').localeCompare(b.hora_inicio || '00:00'));

  // Handler: Add routine schedule
  const handleSalvarRotina = (e: React.FormEvent) => {
    e.preventDefault();
    const ativ = atividades.find((a) => a.id === formRotinaAtividadeId);
    if (!ativ) return;

    onAddAgendamento({
      tipo: 'rotina',
      titulo: ativ.nome,
      data: formRotinaData,
      hora_inicio: formRotinaHoraInicio,
      hora_fim: formRotinaHoraFim,
      atividade_id: ativ.id,
      categoria_id: ativ.categoria_id,
      categoria_nome: ativ.categoria_nome,
      cor: '#3B82F6',
      concluido: false
    });

    setModalRotinaOpen(false);
  };

  // Handler: Add punctual one-off task
  const handleSalvarPontual = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formPontualTitulo.trim()) return;

    onAddAgendamento({
      tipo: 'pontual',
      titulo: formPontualTitulo.trim(),
      data: formPontualData,
      hora_inicio: formPontualHoraInicio,
      hora_fim: formPontualHoraFim,
      tag_livre: formPontualTag.trim() || 'Avulso',
      descricao: formPontualDescricao.trim() || undefined,
      concluido: false
    });

    setFormPontualTitulo('');
    setFormPontualDescricao('');
    setModalPontualOpen(false);
  };

  // Trigger Google Calendar sync simulation
  const handleTriggerSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      setSyncMessage('Google Agenda sincronizado com sucesso! (Modo Leitura: 3 eventos ativos)');
      setTimeout(() => setSyncMessage(null), 4000);
      if (onSyncGoogleCalendar) onSyncGoogleCalendar();
    }, 1200);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner with Quick Actions & Sync telemetry */}
      <div className="bg-[#0d0d0d] rounded-2xl border border-[#222] p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-[#1a1a1a] text-amber-400 border border-[#2a2a2a]">
              <CalendarIcon className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-serif italic text-white">
                  Calendário & Planejador de Rotina
                </h2>
                <span className="text-[10px] font-mono uppercase bg-amber-500/10 text-amber-300 border border-amber-500/25 px-2 py-0.5 rounded-md">
                  Google Calendar Read-Only
                </span>
              </div>
              <p className="text-xs text-[#888] mt-1 font-sans">
                Visualize seus compromissos do Google Agenda, programe atividades de rotina e crie tarefas pontuais sem precisar de categorias.
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setShowGuiaPassoAPasso(!showGuiaPassoAPasso)}
            className="px-3 py-2 rounded-xl text-xs font-medium bg-[#141414] hover:bg-[#1f1f1f] text-amber-400 border border-[#2a2a2a] hover:border-amber-500/40 flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>{showGuiaPassoAPasso ? 'Ocultar Guia' : 'Guia Passo a Passo'}</span>
          </button>

          <button
            onClick={() => setModalPontualOpen(true)}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-[#161616] hover:bg-[#202020] text-purple-300 border border-purple-500/40 hover:border-purple-400 flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
          >
            <CalendarPlus className="w-3.5 h-3.5 text-purple-400" />
            <span>+ Atividade Pontual (Sem Categoria)</span>
          </button>

          <button
            onClick={() => setModalRotinaOpen(true)}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-black flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Agendar Rotina</span>
          </button>
        </div>
      </div>

      {/* Synchronized alert feedback */}
      {syncMessage && (
        <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between font-mono animate-fadeIn">
          <span className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            {syncMessage}
          </span>
          <span className="text-[10px] text-emerald-400/70">API v3 Google Calendar</span>
        </div>
      )}

      {/* Step-by-Step Installation Guide (Expandable) */}
      {showGuiaPassoAPasso && (
        <div className="bg-[#0e0e0e] rounded-2xl border border-amber-500/30 p-6 space-y-6 shadow-xl animate-fadeIn">
          <div className="flex items-start justify-between border-b border-[#222] pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-serif italic text-white">
                  Guia de Configuração: Do Início ao Fim no seu Computador
                </h3>
                <p className="text-xs text-[#888] font-mono mt-0.5">
                  Arquivos locais, configuração da Firestore e visualização da Google Agenda
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowGuiaPassoAPasso(false)}
              className="text-xs text-[#777] hover:text-white px-2 py-1 rounded bg-[#181818] border border-[#2a2a2a]"
            >
              Fechar Guia
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-[#ccc]">
            {/* Passo 1: Arquivos no Computador */}
            <div className="bg-[#121212] rounded-xl border border-[#222] p-4.5 space-y-3">
              <div className="flex items-center gap-2 text-amber-400 font-semibold font-mono text-sm">
                <span>1.</span>
                <h4>Arquivos para Criar na Pasta do Projeto</h4>
              </div>
              <p className="text-[#888] leading-relaxed">
                Crie uma pasta no seu computador (ex: <code className="text-amber-300 font-mono">rotina-bot/</code>) e crie exatamente estes arquivos:
              </p>
              <div className="bg-[#080808] p-3 rounded-lg border border-[#222] font-mono text-[11px] text-[#aaa] space-y-1">
                <div className="text-white font-bold">📁 rotina-bot/</div>
                <div className="pl-4">├── <span className="text-emerald-400 font-semibold">bot.py</span> (Loop do Telegram Bot com telebot)</div>
                <div className="pl-4">├── <span className="text-emerald-400 font-semibold">database.py</span> (Conexão Firestore & coleções)</div>
                <div className="pl-4">├── <span className="text-emerald-400 font-semibold">google_calendar.py</span> (Puxa eventos da Google Agenda)</div>
                <div className="pl-4">├── <span className="text-amber-400">chave-firebase.json</span> (Sua credencial do Firebase)</div>
                <div className="pl-4">├── <span className="text-cyan-400">credentials.json</span> (OAuth/Service Account da Google Agenda)</div>
                <div className="pl-4">├── <span className="text-purple-400">.env</span> (TELEGRAM_TOKEN, etc.)</div>
                <div className="pl-4">└── <span className="text-[#eee]">requirements.txt</span> (Dependências Python)</div>
              </div>
              <p className="text-[11px] text-[#777]">
                💡 Os códigos completos e testados de cada arquivo estão disponíveis na aba <strong>"Códigos Python Prontos"</strong>!
              </p>
            </div>

            {/* Passo 2: Configurar Firestore */}
            <div className="bg-[#121212] rounded-xl border border-[#222] p-4.5 space-y-3">
              <div className="flex items-center gap-2 text-amber-400 font-semibold font-mono text-sm">
                <span>2.</span>
                <h4>Como Configurar o Firebase Firestore</h4>
              </div>
              <ol className="list-decimal pl-4 space-y-2 text-[#aaa] leading-relaxed">
                <li>
                  Acesse <a href="https://console.firebase.google.com" target="_blank" rel="noreferrer" className="text-amber-400 underline">console.firebase.google.com</a> e crie um projeto (ex: <code className="text-amber-300 font-mono">rotina-94433</code>).
                </li>
                <li>
                  No menu lateral esquerdo, clique em <strong>Build &gt; Firestore Database</strong> e clique em <strong>Criar Banco de Dados</strong>.
                </li>
                <li>
                  Escolha a região (ex: <code className="font-mono text-amber-300">southamerica-east1</code> São Paulo ou <code className="font-mono text-amber-300">us-central1</code>) e inicie em <em>Modo de Produção</em>.
                </li>
                <li>
                  Para obter a chave: Vá na <strong>Engrenagem (Configurações do Projeto) &gt; Contas de Serviço (Service accounts)</strong> &gt; Selecione Python &gt; Clique em <strong>Gerar nova chave privada</strong>.
                </li>
                <li>
                  O arquivo baixado deve ser renomeado para <code className="text-amber-300 font-mono">chave-firebase.json</code> e colocado na raiz do seu projeto.
                </li>
              </ol>
            </div>

            {/* Passo 3: Google Agenda */}
            <div className="bg-[#121212] rounded-xl border border-[#222] p-4.5 space-y-3">
              <div className="flex items-center gap-2 text-amber-400 font-semibold font-mono text-sm">
                <span>3.</span>
                <h4>Como Puxar Dados do Google Agenda (Somente Leitura)</h4>
              </div>
              <p className="text-[#888] leading-relaxed">
                Você <strong>não precisa</strong> dar permissão de escrita, apenas leitura dos eventos já existentes:
              </p>
              <ul className="list-disc pl-4 space-y-2 text-[#aaa] leading-relaxed">
                <li>
                  <strong>Método 1 (Mais Simples - iCal Oficial):</strong> Acesse as configurações da sua Google Agenda no navegador &gt; clique no seu calendário &gt; role até <em>"Endereço secreto em formato iCal"</em>. O Python lê essa URL via biblioteca <code className="text-amber-300 font-mono">icalendar</code> sem nem precisar criar credenciais complexas!
                </li>
                <li>
                  <strong>Método 2 (Google Cloud API Oficial):</strong> Vá no <a href="https://console.cloud.google.com" target="_blank" rel="noreferrer" className="text-amber-400 underline">Google Cloud Console</a> &gt; Ative a <strong>Google Calendar API</strong> &gt; Crie credenciais OAuth 2.0 com escopo <code className="text-amber-300 font-mono">calendar.readonly</code> &gt; Baixe o <code className="font-mono text-amber-300">credentials.json</code>.
                </li>
                <li>
                  O script Python roda em background ou sob demanda quando você solicita o resumo do dia no Telegram com <code className="text-amber-300 font-mono">/agenda</code>.
                </li>
              </ul>
            </div>

            {/* Passo 4: Atividades Pontuais vs Rotina */}
            <div className="bg-[#121212] rounded-xl border border-[#222] p-4.5 space-y-3">
              <div className="flex items-center gap-2 text-amber-400 font-semibold font-mono text-sm">
                <span>4.</span>
                <h4>Atividades Pontuais (Sem Criar Categorias)</h4>
              </div>
              <p className="text-[#888] leading-relaxed">
                Como você solicitou, há tarefas do dia a dia (ex: <em>"Ir ao Dentista"</em>, <em>"Trocar bateria da chave"</em>, <em>"Reunião de condomínio"</em>) que não fazem sentido ter uma categoria nem contar para meta de score:
              </p>
              <ul className="list-disc pl-4 space-y-1.5 text-[#aaa]">
                <li>
                  No Firestore, criamos a coleção <code className="text-purple-300 font-mono">compromissos_pontuais</code> separada de <code className="text-amber-300 font-mono">atividades_cadastradas</code>.
                </li>
                <li>
                  O documento tem apenas: <code className="font-mono text-[#ddd]">titulo</code>, <code className="font-mono text-[#ddd]">data</code>, <code className="font-mono text-[#ddd]">hora</code>, <code className="font-mono text-[#ddd]">concluido: bool</code> e uma tag opcional de texto livre.
                </li>
                <li>
                  No Telegram, você pode adicionar diretamente: <code className="text-amber-300 font-mono">/agendar 14:30 Dentista</code> sem escolher categoria nenhuma!
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Calendar Header Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#0d0d0d] p-4 rounded-2xl border border-[#222]">
        {/* Month Selector */}
        <div className="flex items-center gap-3">
          <div className="flex items-center bg-[#161616] border border-[#262626] rounded-xl p-1">
            <button
              onClick={prevMonth}
              className="p-1.5 rounded-lg hover:bg-[#222] text-[#888] hover:text-white transition-colors cursor-pointer"
              title="Mês anterior"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="font-serif italic text-white text-base px-3 min-w-[140px] text-center">
              {nomesMeses[currentMonth]} {currentYear}
            </span>
            <button
              onClick={nextMonth}
              className="p-1.5 rounded-lg hover:bg-[#222] text-[#888] hover:text-white transition-colors cursor-pointer"
              title="Próximo mês"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={setHoje}
            className="text-xs font-mono px-3 py-1.5 rounded-xl bg-[#181818] border border-[#2c2c2c] text-[#aaa] hover:text-amber-300 hover:border-amber-500/40 transition-colors cursor-pointer"
          >
            Hoje (07 Set)
          </button>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
          <span className="text-[10px] font-mono text-[#666] uppercase tracking-wider shrink-0 mr-1">
            Filtrar:
          </span>
          {[
            { id: 'todos', label: 'Todos', count: agendamentos.length, color: 'text-white' },
            {
              id: 'rotina',
              label: 'Rotina',
              count: agendamentos.filter((a) => a.tipo === 'rotina').length,
              color: 'text-blue-400'
            },
            {
              id: 'pontual',
              label: 'Pontuais',
              count: agendamentos.filter((a) => a.tipo === 'pontual').length,
              color: 'text-purple-400'
            },
            {
              id: 'google_agenda',
              label: 'Google Agenda',
              count: agendamentos.filter((a) => a.tipo === 'google_agenda').length,
              color: 'text-emerald-400'
            }
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setFiltroTipo(f.id as any)}
              className={`text-xs px-2.5 py-1.5 rounded-xl border font-sans font-medium transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                filtroTipo === f.id
                  ? 'bg-[#1e1e1e] border-amber-500/40 text-white shadow-xs'
                  : 'bg-[#121212] border-[#222] text-[#777] hover:text-[#bbb] hover:border-[#333]'
              }`}
            >
              <span className={f.color}>{f.label}</span>
              <span className="text-[10px] font-mono opacity-70">({f.count})</span>
            </button>
          ))}

          {/* Sync Button */}
          <button
            onClick={handleTriggerSync}
            disabled={isSyncing}
            className="ml-2 p-2 rounded-xl bg-[#161616] border border-[#2a2a2a] hover:border-emerald-500/40 text-emerald-400 transition-colors cursor-pointer disabled:opacity-50"
            title="Sincronizar Google Agenda"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Main Grid: Calendar Month on Left + Day Agenda on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Month View Grid (8 cols) */}
        <div className="lg:col-span-8 bg-[#0d0d0d] rounded-2xl border border-[#222] p-5 shadow-xs">
          {/* Days of week header */}
          <div className="grid grid-cols-7 gap-2 mb-2 text-center text-[11px] font-mono uppercase tracking-wider text-[#666]">
            <div>Seg</div>
            <div>Ter</div>
            <div>Qua</div>
            <div>Qui</div>
            <div>Sex</div>
            <div className="text-[#888]">Sáb</div>
            <div className="text-[#888]">Dom</div>
          </div>

          {/* Days cells */}
          <div className="grid grid-cols-7 gap-2">
            {/* Empty cells before month start */}
            {Array.from({ length: startingOffset }).map((_, i) => (
              <div
                key={`empty-${i}`}
                className="h-24 rounded-xl bg-[#090909] border border-[#181818] opacity-30 p-1.5"
              />
            ))}

            {/* Days in month */}
            {Array.from({ length: daysInCurrentMonth }).map((_, i) => {
              const dayNum = i + 1;
              const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
              const isSelected = selectedDate === dateStr;
              const isToday = dateStr === '2026-09-07';

              // Items for this day
              const dayItems = filteredItems.filter((it) => it.data === dateStr);
              const rotinaCount = dayItems.filter((it) => it.tipo === 'rotina').length;
              const pontualCount = dayItems.filter((it) => it.tipo === 'pontual').length;
              const gcalCount = dayItems.filter((it) => it.tipo === 'google_agenda').length;

              return (
                <div
                  key={`day-${dayNum}`}
                  onClick={() => setSelectedDate(dateStr)}
                  className={`h-24 rounded-xl border p-2 flex flex-col justify-between transition-all cursor-pointer select-none relative group ${
                    isSelected
                      ? 'bg-[#181818] border-amber-500 shadow-md ring-1 ring-amber-500/20'
                      : isToday
                      ? 'bg-[#141414] border-amber-500/40 hover:border-amber-500/60'
                      : 'bg-[#101010] border-[#1c1c1c] hover:border-[#2a2a2a] hover:bg-[#141414]'
                  }`}
                >
                  {/* Day header */}
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs font-mono font-bold ${
                        isToday
                          ? 'text-amber-400 bg-amber-500/20 px-1.5 py-0.5 rounded'
                          : isSelected
                          ? 'text-white'
                          : 'text-[#888]'
                      }`}
                    >
                      {dayNum}
                    </span>

                    {/* Today indicator label */}
                    {isToday && (
                      <span className="text-[9px] font-mono uppercase tracking-widest text-amber-400 hidden sm:inline">
                        Hoje
                      </span>
                    )}
                  </div>

                  {/* Badges / summary in cell */}
                  <div className="space-y-1 overflow-hidden">
                    {dayItems.slice(0, 2).map((it) => (
                      <div
                        key={it.id}
                        className={`text-[10px] truncate px-1.5 py-0.5 rounded font-sans leading-tight border ${
                          it.tipo === 'rotina'
                            ? 'bg-blue-950/40 text-blue-300 border-blue-900/40'
                            : it.tipo === 'pontual'
                            ? 'bg-purple-950/40 text-purple-300 border-purple-900/40'
                            : 'bg-emerald-950/40 text-emerald-300 border-emerald-900/40'
                        } ${it.concluido ? 'line-through opacity-60' : ''}`}
                      >
                        <span className="font-mono text-[9px] mr-1 opacity-70">
                          {it.hora_inicio || ''}
                        </span>
                        {it.titulo}
                      </div>
                    ))}

                    {dayItems.length > 2 && (
                      <div className="text-[9px] font-mono text-[#777] pl-1">
                        +{dayItems.length - 2} outros
                      </div>
                    )}
                  </div>

                  {/* Bottom indicators */}
                  <div className="flex items-center gap-1 pt-1">
                    {rotinaCount > 0 && (
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-400" title={`${rotinaCount} Rotina`} />
                    )}
                    {pontualCount > 0 && (
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-400" title={`${pontualCount} Pontual`} />
                    )}
                    {gcalCount > 0 && (
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" title={`${gcalCount} Google Agenda`} />
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Legend */}
          <div className="mt-5 pt-4 border-t border-[#1a1a1a] flex flex-wrap items-center justify-between gap-3 text-[11px] text-[#777]">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
                <span>Atividade de Rotina (com Categoria)</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-500"></span>
                <span>Atividade Pontual (Sem Categoria)</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                <span>Google Agenda (Somente Leitura)</span>
              </span>
            </div>
            <div className="font-mono text-[10px] text-[#555]">
              Clique em um dia para ver os detalhes
            </div>
          </div>
        </div>

        {/* Day Detail & Agenda Timeline (4 cols) */}
        <div className="lg:col-span-4 bg-[#0d0d0d] rounded-2xl border border-[#222] p-5 shadow-xs space-y-4">
          {/* Day header */}
          <div className="border-b border-[#1f1f1f] pb-3 flex items-start justify-between">
            <div>
              <span className="text-[10px] font-mono uppercase tracking-widest text-[#777]">
                Agenda do Dia
              </span>
              <h3 className="text-base font-serif italic text-white mt-0.5">
                {(() => {
                  const [y, m, d] = selectedDate.split('-').map(Number);
                  const dateObj = new Date(y, m - 1, d);
                  const diasSemana = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
                  return `${diasSemana[dateObj.getDay()]}, ${d} de ${nomesMeses[m - 1]}`;
                })()}
              </h3>
            </div>

            <div className="text-right">
              <span className="text-xs font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                {selectedDayItems.length} {selectedDayItems.length === 1 ? 'item' : 'itens'}
              </span>
            </div>
          </div>

          {/* Quick add buttons inside the day */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                setFormPontualData(selectedDate);
                setModalPontualOpen(true);
              }}
              className="px-2.5 py-1.5 rounded-lg bg-[#141414] hover:bg-[#1c1c1c] text-purple-300 border border-purple-900/40 text-left text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <CalendarPlus className="w-3 h-3 text-purple-400" />
              <span>+ Pontual</span>
            </button>
            <button
              onClick={() => {
                setFormRotinaData(selectedDate);
                setModalRotinaOpen(true);
              }}
              className="px-2.5 py-1.5 rounded-lg bg-[#141414] hover:bg-[#1c1c1c] text-blue-300 border border-blue-900/40 text-left text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3 h-3 text-blue-400" />
              <span>+ Rotina</span>
            </button>
          </div>

          {/* Day Items List */}
          <div className="space-y-2.5 max-h-[480px] overflow-y-auto pr-1">
            {selectedDayItems.length === 0 ? (
              <div className="py-12 text-center text-xs text-[#666] space-y-2 bg-[#090909] rounded-xl border border-[#1a1a1a]">
                <CalendarIcon className="w-8 h-8 text-[#444] mx-auto opacity-50" />
                <p>Nenhuma atividade ou compromisso para este dia.</p>
                <p className="text-[11px] text-[#555]">
                  Use os botões acima para agendar uma atividade de rotina ou criar um compromisso pontual.
                </p>
              </div>
            ) : (
              selectedDayItems.map((item) => (
                <div
                  key={item.id}
                  className={`p-3.5 rounded-xl border transition-all text-xs ${
                    item.tipo === 'rotina'
                      ? 'bg-[#11161d] border-blue-900/40'
                      : item.tipo === 'pontual'
                      ? 'bg-[#17121c] border-purple-900/40'
                      : 'bg-[#101914] border-emerald-900/40'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2.5 flex-1">
                      {/* Completion checkmark (only for non-google items) */}
                      {item.tipo !== 'google_agenda' ? (
                        <button
                          onClick={() => onToggleConcluido(item.id)}
                          className="mt-0.5 text-[#666] hover:text-amber-400 transition-colors cursor-pointer"
                          title="Marcar como concluído"
                        >
                          {item.concluido ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                          ) : (
                            <Circle className="w-4 h-4" />
                          )}
                        </button>
                      ) : (
                        <div className="mt-0.5 w-4 h-4 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center shrink-0">
                          <span className="text-[9px] font-bold text-emerald-400">G</span>
                        </div>
                      )}

                      <div className="flex-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span
                            className={`font-semibold text-sm ${
                              item.concluido
                                ? 'line-through text-[#666]'
                                : 'text-white'
                            }`}
                          >
                            {item.titulo}
                          </span>
                        </div>

                        {/* Badges & Meta */}
                        <div className="flex items-center gap-2 mt-1.5 flex-wrap text-[10px] font-mono">
                          {item.hora_inicio && (
                            <span className="flex items-center gap-1 text-[#aaa] bg-[#1a1a1a] px-1.5 py-0.5 rounded border border-[#2a2a2a]">
                              <Clock className="w-3 h-3 text-amber-400" />
                              {item.hora_inicio} {item.hora_fim ? `- ${item.hora_fim}` : ''}
                            </span>
                          )}

                          {item.tipo === 'rotina' && item.categoria_nome && (
                            <span className="bg-blue-500/15 text-blue-300 border border-blue-500/30 px-1.5 py-0.5 rounded">
                              {item.categoria_nome}
                            </span>
                          )}

                          {item.tipo === 'pontual' && (
                            <span className="bg-purple-500/15 text-purple-300 border border-purple-500/30 px-1.5 py-0.5 rounded flex items-center gap-1">
                              <Tag className="w-2.5 h-2.5 text-purple-400" />
                              {item.tag_livre || 'Pontual'} (Sem Categoria)
                            </span>
                          )}

                          {item.tipo === 'google_agenda' && (
                            <span className="bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.5 rounded">
                              Google Agenda (Leitura)
                            </span>
                          )}
                        </div>

                        {/* Description / Location */}
                        {item.descricao && (
                          <p className="text-[11px] text-[#888] mt-1.5 font-sans leading-relaxed">
                            {item.descricao}
                          </p>
                        )}

                        {item.local && (
                          <p className="text-[11px] text-[#777] mt-1 font-sans flex items-center gap-1">
                            <MapPin className="w-3 h-3 text-amber-400 shrink-0" />
                            {item.local}
                          </p>
                        )}

                        {/* Google Meet Link */}
                        {item.link_reuniao && (
                          <div className="mt-2">
                            <a
                              href={item.link_reuniao}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#16231a] hover:bg-[#1d3023] text-emerald-300 border border-emerald-500/30 text-[11px] font-mono transition-colors"
                            >
                              <Video className="w-3 h-3 text-emerald-400" />
                              Entrar na Reunião (Meet)
                              <ExternalLink className="w-2.5 h-2.5 opacity-60" />
                            </a>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Delete button (for non-google items) */}
                    {item.tipo !== 'google_agenda' && (
                      <button
                        onClick={() => onDeleteAgendamento(item.id)}
                        className="p-1 rounded-lg text-[#555] hover:text-red-400 hover:bg-[#1f1f1f] transition-colors cursor-pointer"
                        title="Remover compromisso"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Quick info footer */}
          <div className="p-3 rounded-xl bg-[#121212] border border-[#222] text-[11px] text-[#777] space-y-1">
            <span className="font-semibold text-[#aaa] block">Sincronização Ativa:</span>
            <p>
              Eventos do Google Agenda são exibidos ao lado da sua rotina habitual sem poluir seu banco nem alterar seu calendário original.
            </p>
          </div>
        </div>
      </div>

      {/* Modal: Agendar Atividade da Rotina */}
      {modalRotinaOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4">
          <div className="bg-[#0f0f0f] border border-[#282828] rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl animate-fadeIn">
            <div className="flex items-center justify-between border-b border-[#222] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20">
                  <Layers className="w-4 h-4" />
                </div>
                <h3 className="text-base font-serif italic text-white">
                  Agendar Atividade da Rotina
                </h3>
              </div>
              <button
                onClick={() => setModalRotinaOpen(false)}
                className="text-[#666] hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSalvarRotina} className="space-y-4 text-xs">
              <div>
                <label className="block text-[#aaa] font-medium mb-1">
                  Selecione a Atividade Cadastrada:
                </label>
                <select
                  value={formRotinaAtividadeId}
                  onChange={(e) => setFormRotinaAtividadeId(e.target.value)}
                  className="w-full bg-[#181818] border border-[#333] rounded-xl px-3 py-2.5 text-white focus:outline-hidden focus:border-amber-500"
                >
                  {atividades.map((ativ) => (
                    <option key={ativ.id} value={ativ.id}>
                      {ativ.nome} ({ativ.categoria_nome})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[#aaa] font-medium mb-1">
                  Data:
                </label>
                <input
                  type="date"
                  value={formRotinaData}
                  onChange={(e) => setFormRotinaData(e.target.value)}
                  className="w-full bg-[#181818] border border-[#333] rounded-xl px-3 py-2 text-white font-mono focus:outline-hidden focus:border-amber-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#aaa] font-medium mb-1">
                    Horário de Início:
                  </label>
                  <input
                    type="time"
                    value={formRotinaHoraInicio}
                    onChange={(e) => setFormRotinaHoraInicio(e.target.value)}
                    className="w-full bg-[#181818] border border-[#333] rounded-xl px-3 py-2 text-white font-mono focus:outline-hidden focus:border-amber-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[#aaa] font-medium mb-1">
                    Horário de Término:
                  </label>
                  <input
                    type="time"
                    value={formRotinaHoraFim}
                    onChange={(e) => setFormRotinaHoraFim(e.target.value)}
                    className="w-full bg-[#181818] border border-[#333] rounded-xl px-3 py-2 text-white font-mono focus:outline-hidden focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-[#222] flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setModalRotinaOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs text-[#888] hover:text-white bg-[#161616] border border-[#2a2a2a]"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-black shadow-xs cursor-pointer"
                >
                  Confirmar Agendamento
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Nova Atividade Pontual (SEM CATEGORIA) */}
      {modalPontualOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4">
          <div className="bg-[#0f0f0f] border border-[#282828] rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl animate-fadeIn">
            <div className="flex items-center justify-between border-b border-[#222] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20">
                  <CalendarPlus className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-serif italic text-white">
                    Nova Atividade Pontual
                  </h3>
                  <span className="text-[10px] font-mono text-purple-400 block">
                    Sem necessidade de criar categoria
                  </span>
                </div>
              </div>
              <button
                onClick={() => setModalPontualOpen(false)}
                className="text-[#666] hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-[#888] bg-[#15121a] p-3 rounded-xl border border-purple-950/60 leading-relaxed font-sans">
              Ideal para compromissos avulsos como <strong>Dentista</strong>, <strong>Lembrar de comprar remédio</strong>, <strong>Reunião de condomínio</strong> ou recados únicos.
            </p>

            <form onSubmit={handleSalvarPontual} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-[#aaa] font-medium mb-1">
                  Título do Compromisso / Tarefa:
                </label>
                <input
                  type="text"
                  placeholder="Ex: Consulta Médica, Renovar CNH, Consertar Notebook"
                  value={formPontualTitulo}
                  onChange={(e) => setFormPontualTitulo(e.target.value)}
                  className="w-full bg-[#181818] border border-[#333] rounded-xl px-3.5 py-2.5 text-white placeholder-[#555] focus:outline-hidden focus:border-purple-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#aaa] font-medium mb-1">
                    Data:
                  </label>
                  <input
                    type="date"
                    value={formPontualData}
                    onChange={(e) => setFormPontualData(e.target.value)}
                    className="w-full bg-[#181818] border border-[#333] rounded-xl px-3 py-2 text-white font-mono focus:outline-hidden focus:border-purple-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[#aaa] font-medium mb-1">
                    Tag Livre (opcional):
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: Saúde, Casa, Recado"
                    value={formPontualTag}
                    onChange={(e) => setFormPontualTag(e.target.value)}
                    className="w-full bg-[#181818] border border-[#333] rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-purple-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#aaa] font-medium mb-1">
                    Horário Início:
                  </label>
                  <input
                    type="time"
                    value={formPontualHoraInicio}
                    onChange={(e) => setFormPontualHoraInicio(e.target.value)}
                    className="w-full bg-[#181818] border border-[#333] rounded-xl px-3 py-2 text-white font-mono focus:outline-hidden focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-[#aaa] font-medium mb-1">
                    Horário Término:
                  </label>
                  <input
                    type="time"
                    value={formPontualHoraFim}
                    onChange={(e) => setFormPontualHoraFim(e.target.value)}
                    className="w-full bg-[#181818] border border-[#333] rounded-xl px-3 py-2 text-white font-mono focus:outline-hidden focus:border-purple-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[#aaa] font-medium mb-1">
                  Observações / Detalhes:
                </label>
                <textarea
                  rows={2}
                  placeholder="Ex: Levar documento com foto, endereço na Rua X, número 120"
                  value={formPontualDescricao}
                  onChange={(e) => setFormPontualDescricao(e.target.value)}
                  className="w-full bg-[#181818] border border-[#333] rounded-xl px-3.5 py-2 text-white placeholder-[#555] focus:outline-hidden focus:border-purple-500"
                />
              </div>

              <div className="pt-3 border-t border-[#222] flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setModalPontualOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs text-[#888] hover:text-white bg-[#161616] border border-[#2a2a2a]"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-purple-600 hover:bg-purple-500 text-white shadow-xs cursor-pointer"
                >
                  Criar Atividade Pontual
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
