import React, { useState } from 'react';
import { Copy, Check, FileCode, Terminal, HelpCircle, Sparkles } from 'lucide-react';

export const CodeViewer: React.FC = () => {
  const [activeFile, setActiveFile] = useState<'database' | 'bot' | 'google_calendar' | 'agendamento' | 'requirements' | 'cloudrun'>('database');
  const [copied, setCopied] = useState(false);

  const DATABASE_CODE = `"""
Módulo de Banco de Dados (database.py)
Gerencia a conexão com o Firebase Firestore e operações CRUD para:
- categorias
- atividades_cadastradas
"""

import os
from typing import Dict, List, Optional, Any
import firebase_admin
from firebase_admin import credentials, firestore
from google.cloud.firestore import DocumentReference

KEY_PATH = os.environ.get("FIREBASE_CREDENTIALS_PATH", "chave-firebase.json")

if not firebase_admin._apps:
    if os.path.exists(KEY_PATH):
        cred = credentials.Certificate(KEY_PATH)
        firebase_admin.initialize_app(cred)
    else:
        firebase_admin.initialize_app()

db = firestore.client()

# =====================================================================
# 1. CATEGORIAS
# =====================================================================

def cadastrar_categoria(nome: str, unidade: str, peso: Any) -> str:
    """Salva uma categoria no Firestore."""
    dados = {
        "nome": nome.strip(),
        "unidade_padrao": unidade.strip().lower(),
        "peso_no_score": int(peso),
        "criado_em": firestore.SERVER_TIMESTAMP
    }
    _, doc_ref = db.collection("categorias").add(dados)
    return doc_ref.id


def listar_categorias() -> List[str]:
    """Retorna lista formatada de categorias para o Telegram."""
    docs = db.collection("categorias").stream()
    return [
        f"📂 *{d.get('nome')}* (Unidade: \`{d.get('unidade_padrao')}\` | Peso: \`{d.get('peso_no_score')}%\`)"
        for d in (doc.to_dict() for doc in docs)
    ]


def listar_categorias_dict() -> List[Dict[str, Any]]:
    """Retorna lista de dicionários com os IDs para alimentar botões inline do bot."""
    docs = db.collection("categorias").stream()
    categorias = []
    for doc in docs:
        d = doc.to_dict()
        d["id"] = doc.id
        categorias.append(d)
    categorias.sort(key=lambda x: x.get("nome", "").lower())
    return categorias


def obter_categoria(categoria_id: str) -> Optional[Dict[str, Any]]:
    """Recupera dados de uma categoria por ID."""
    doc = db.collection("categorias").document(categoria_id).get()
    if doc.exists:
        d = doc.to_dict()
        d["id"] = doc.id
        return d
    return None


# =====================================================================
# 2. ATIVIDADES CADASTRADAS (COM VÍNCULO NO FIRESTORE)
# =====================================================================

def cadastrar_atividade(
    nome: str,
    categoria_id: str,
    recorrente: bool = True,
    unidade: Optional[str] = None,
    afeta_meta: bool = True,
    campos_extras: Optional[Dict[str, Any]] = None
) -> str:
    """
    Cadastra uma atividade vinculada a uma categoria existente.
    
    A Regra de Vínculo no Firestore:
    1. 'categoria_id': String simples para buscas com .where('categoria_id', '==', id)
    2. 'categoria_ref': DocumentReference formal para navegação direta .get()
    3. 'categoria_nome': Desnormalização para evitar leituras extras no banco
    """
    cat_dados = obter_categoria(categoria_id)
    if not cat_dados:
        raise ValueError(f"Categoria com ID '{categoria_id}' não foi encontrada.")

    unidade_final = unidade.strip().lower() if unidade else cat_dados.get("unidade_padrao", "un")

    # Criação da referência nativa do Firestore
    categoria_ref: DocumentReference = db.collection("categorias").document(categoria_id)

    dados_atividade = {
        "nome": nome.strip(),
        "categoria_id": categoria_id,
        "categoria_ref": categoria_ref,
        "categoria_nome": cat_dados.get("nome", "Sem categoria"),
        "recorrente": bool(recorrente),
        "unidade": unidade_final,
        "afeta_meta": bool(afeta_meta),
        "campos_extras": campos_extras or {},
        "criado_em": firestore.SERVER_TIMESTAMP
    }

    _, doc_ref = db.collection("atividades_cadastradas").add(dados_atividade)
    return doc_ref.id


def listar_atividades(categoria_id: Optional[str] = None) -> List[str]:
    """Retorna atividades formatadas em Markdown para o Telegram."""
    query = db.collection("atividades_cadastradas")
    if categoria_id:
        query = query.where("categoria_id", "==", categoria_id)

    docs = query.stream()
    lista = []
    for doc in docs:
        d = doc.to_dict()
        rec = "🔄 Recorrente" if d.get("recorrente", True) else "⚡ Pontual"
        meta = "🎯 Conta meta" if d.get("afeta_meta", True) else "📝 Registro simples"
        lista.append(
            f"🔹 *{d.get('nome')}*\\n"
            f"   📁 Categoria: _{d.get('categoria_nome')}_\\n"
            f"   📏 Unidade: \`{d.get('unidade')}\` | {rec} | {meta}"
        )
    return lista`;

  const BOT_CODE = `"""
Bot do Telegram para Gestão de Rotina e Metas (bot.py)
Fluxo interativo com InlineKeyboards para associar Atividade à Categoria.
"""

import os
import telebot
from telebot import types
from database import (
    cadastrar_categoria,
    listar_categorias,
    listar_categorias_dict,
    obter_categoria,
    cadastrar_atividade,
    listar_atividades,
)

TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "8949673934:AAEjhmDizSs0hbhhDVXDnNXf8fLr1PA1KlQ")
bot = telebot.TeleBot(TOKEN)
user_sessions = {}

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    texto = (
        "👋 *Olá! Bem-vindo ao Sistema de Gestão de Rotina & Metas!*\\n\\n"
        "📁 *Gestão de Categorias:*\\n"
        "• \`/categorias\` - Ver categorias\\n"
        "• \`/nova_categoria\` - Cadastrar categoria\\n\\n"
        "⚡ *Gestão de Atividades:*\\n"
        "• \`/atividades\` - Ver atividades cadastradas\\n"
        "• \`/nova_atividade\` - Cadastrar atividade com seleção de categoria"
    )
    bot.reply_to(message, texto, parse_mode="Markdown")

@bot.message_handler(commands=['categorias'])
def mostrar_categorias(message):
    cats = listar_categorias()
    if not cats:
        bot.send_message(message.chat.id, "📭 Nenhuma categoria encontrada. Use /nova_categoria")
    else:
        bot.send_message(message.chat.id, "📋 *Categorias:*\\n\\n" + "\\n".join(cats), parse_mode="Markdown")

@bot.message_handler(commands=['atividades'])
def mostrar_atividades(message):
    ativs = listar_atividades()
    if not ativs:
        bot.send_message(message.chat.id, "📭 Nenhuma atividade cadastrada. Use /nova_atividade")
    else:
        bot.send_message(message.chat.id, "📋 *Atividades:*\\n\\n" + "\\n\\n".join(ativs), parse_mode="Markdown")

# Fluxo de Nova Atividade com Botões Inline
@bot.message_handler(commands=['nova_atividade'])
def iniciar_cadastro_atividade(message):
    user_sessions[message.chat.id] = {}
    msg = bot.reply_to(
        message,
        "🏋️ *Nova Atividade - Passo 1/3*\\n\\nQual é o nome da atividade?\\nEx: \`Treino de Musculação\`",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(msg, passo_nome_atividade)

def passo_nome_atividade(message):
    chat_id = message.chat.id
    nome = message.text.strip()
    user_sessions[chat_id] = {"nome": nome}

    categorias = listar_categorias_dict()
    if not categorias:
        bot.reply_to(message, "⚠️ Cadastre uma categoria primeiro com /nova_categoria.")
        return

    markup = types.InlineKeyboardMarkup(row_width=2)
    botoes = [
        types.InlineKeyboardButton(f"📁 {c['nome']}", callback_data=f"cat_{c['id']}")
        for c in categorias
    ]
    markup.add(*botoes)

    bot.send_message(
        chat_id,
        f"🎯 *Atividade:* _{nome}_\\n\\nSelecione a categoria correspondente:",
        reply_markup=markup,
        parse_mode="Markdown"
    )

@bot.callback_query_handler(func=lambda call: call.data.startswith("cat_"))
def callback_categoria(call):
    chat_id = call.message.chat.id
    cat_id = call.data.replace("cat_", "")
    cat = obter_categoria(cat_id)
    if not cat: return

    user_sessions[chat_id]["categoria_id"] = cat_id
    user_sessions[chat_id]["categoria_nome"] = cat["nome"]
    user_sessions[chat_id]["unidade_padrao"] = cat.get("unidade_padrao", "minutos")

    bot.answer_callback_query(call.id, f"Selecionada: {cat['nome']}")

    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(f"✅ Usar unidade '{cat.get('unidade_padrao')}'", callback_data="uni_default"),
        types.InlineKeyboardButton("✏️ Digitar outra unidade", callback_data="uni_custom")
    )
    bot.edit_message_text(
        f"✅ *Categoria:* {cat['nome']}\\n📌 *Atividade:* {user_sessions[chat_id]['nome']}\\n\\nEscolha a unidade:",
        chat_id=chat_id,
        message_id=call.message.message_id,
        reply_markup=markup,
        parse_mode="Markdown"
    )

@bot.callback_query_handler(func=lambda call: call.data in ["uni_default", "uni_custom"])
def callback_unidade(call):
    chat_id = call.message.chat.id
    if call.data == "uni_default":
        user_sessions[chat_id]["unidade"] = user_sessions[chat_id]["unidade_padrao"]
        perguntar_recorrencia(chat_id, call.message.message_id)
    else:
        msg = bot.send_message(chat_id, "Digite a unidade desejada (ex: km, páginas, repetições):")
        bot.register_next_step_handler(msg, passo_unidade_custom)

def passo_unidade_custom(message):
    user_sessions[message.chat.id]["unidade"] = message.text.strip().lower()
    perguntar_recorrencia(message.chat.id)

def perguntar_recorrencia(chat_id, msg_id=None):
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("🔄 Sim (Recorrente)", callback_data="rec_sim"),
        types.InlineKeyboardButton("⚡ Não (Pontual)", callback_data="rec_nao")
    )
    bot.send_message(chat_id, "🔁 A atividade é recorrente na sua rotina habitual?", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data in ["rec_sim", "rec_nao"])
def callback_salvar(call):
    chat_id = call.message.chat.id
    sessao = user_sessions.get(chat_id, {})
    recorrente = (call.data == "rec_sim")

    doc_id = cadastrar_atividade(
        nome=sessao["nome"],
        categoria_id=sessao["categoria_id"],
        recorrente=recorrente,
        unidade=sessao["unidade"],
        afeta_meta=True
    )

    bot.edit_message_text(
        f"🎉 *Atividade Cadastrada no Firestore!*\\n\\n"
        f"🔹 *Nome:* {sessao['nome']}\\n"
        f"📁 *Categoria:* {sessao['categoria_nome']}\\n"
        f"📏 *Unidade:* \`{sessao['unidade']}\`\\n"
        f"🆔 *ID Firestore:* \`{doc_id}\`",
        chat_id=chat_id,
        message_id=call.message.message_id,
        parse_mode="Markdown"
    )
    if chat_id in user_sessions:
        del user_sessions[chat_id]

if __name__ == "__main__":
    print("Bot em execução...")
    bot.infinity_polling()`;

  const GOOGLE_CALENDAR_CODE = `"""
Módulo de Integração com Google Agenda (google_calendar.py)
MODO SOMENTE LEITURA (READ-ONLY)
Puxa seus compromissos e eventos sem alterar sua agenda nem sobrecarregar o sistema.
"""

import datetime
import os.path
from typing import List, Dict, Any

# Método 1: Google Calendar API Oficial v3
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

# Escopo restrito a SOMENTE LEITURA para sua segurança
SCOPES = ['https://www.googleapis.com/auth/calendar.readonly']

def obter_servico_google_calendar():
    """Autentica com credentials.json e gera o token.json automaticamente."""
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            if not os.path.exists('credentials.json'):
                print("Aviso: 'credentials.json' não encontrado. Obtenha no Google Cloud Console.")
                return None
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token:
            token.write(creds.to_json())

    return build('calendar', 'v3', credentials=creds)


def listar_eventos_do_dia(data_alvo: str = None) -> List[Dict[str, Any]]:
    """
    Retorna os eventos da Google Agenda para a data informada (YYYY-MM-DD).
    Se data_alvo for None, utiliza a data de hoje.
    """
    servico = obter_servico_google_calendar()
    if not servico:
        return []

    if data_alvo:
        data_inicio = datetime.datetime.strptime(data_alvo, "%Y-%m-%d")
    else:
        data_inicio = datetime.date.today()

    inicio_iso = datetime.datetime.combine(data_inicio, datetime.time.min).isoformat() + 'Z'
    fim_iso = datetime.datetime.combine(data_inicio, datetime.time.max).isoformat() + 'Z'

    try:
        events_result = servico.events().list(
            calendarId='primary',
            timeMin=inicio_iso,
            timeMax=fim_iso,
            singleEvents=True,
            orderBy='startTime'
        ).execute()

        eventos = events_result.get('items', [])
        lista_formatada = []

        for evt in eventos:
            inicio = evt['start'].get('dateTime', evt['start'].get('date'))
            hora_inicio = inicio[11:16] if 'T' in inicio else "Dia inteiro"
            
            fim = evt['end'].get('dateTime', evt['end'].get('date'))
            hora_fim = fim[11:16] if 'T' in fim else ""

            lista_formatada.append({
                "id": evt.get('id'),
                "titulo": evt.get('summary', 'Sem Título'),
                "hora_inicio": hora_inicio,
                "hora_fim": hora_fim,
                "local": evt.get('location', ''),
                "link_meet": evt.get('hangoutLink', ''),
                "tipo": "google_agenda"
            })

        return lista_formatada
    except Exception as e:
        print(f"Erro ao buscar Google Calendar: {e}")
        return []


# =====================================================================
# Método 2 (Alternativo ultraleve sem API Key - formato iCal .ics)
# =====================================================================
def listar_eventos_via_ical(url_ical_secreta: str):
    """
    Lê eventos diretamente do link secreto iCal fornecido pelas
    Configurações da sua Google Agenda (sem precisar de Cloud Console).
    """
    import urllib.request
    from icalendar import Calendar
    
    req = urllib.request.urlopen(url_ical_secreta)
    cal = Calendar.from_ical(req.read())
    eventos = []
    for component in cal.walk('vevent'):
        eventos.append({
            "titulo": str(component.get('summary')),
            "inicio": component.get('dtstart').dt,
            "descricao": str(component.get('description', ''))
        })
    return eventos`;

  const AGENDAMENTO_CODE = `"""
Módulo de Agendamentos & Compromissos Pontuais (agendamento_service.py)
Gerencia:
1. Agendamentos de Rotina (vinculados a atividades cadastradas com DocumentReference)
2. Compromissos Pontuais (SEM necessidade de criar categorias, ex: Dentista, Compras, etc.)
"""

from typing import Dict, List, Any, Optional
import firebase_admin
from firebase_admin import firestore
from database import db

# =====================================================================
# 1. ATIVIDADES PONTUAIS (SEM CATEGORIA)
# =====================================================================

def cadastrar_compromisso_pontual(
    titulo: str,
    data: str, # YYYY-MM-DD
    hora: Optional[str] = None, # HH:mm
    tag_livre: str = "Pessoal",
    observacoes: str = ""
) -> str:
    """
    Cria um compromisso avulso no Firestore na coleção 'compromissos_pontuais'.
    NÃO precisa de categoria prévia nem afeta metas semanais.
    """
    dados = {
        "titulo": titulo.strip(),
        "data": data,
        "hora": hora or "A definir",
        "tag_livre": tag_livre.strip(),
        "observacoes": observacoes.strip(),
        "concluido": False,
        "criado_em": firestore.SERVER_TIMESTAMP
    }
    _, doc_ref = db.collection("compromissos_pontuais").add(dados)
    return doc_ref.id


def alternar_conclusao_pontual(doc_id: str, novo_status: bool):
    """Marca ou desmarca um compromisso pontual como concluído."""
    db.collection("compromissos_pontuais").document(doc_id).update({
        "concluido": novo_status
    })


# =====================================================================
# 2. AGENDAR ATIVIDADE DA ROTINA
# =====================================================================

def agendar_atividade_rotina(
    atividade_id: str,
    data: str, # YYYY-MM-DD
    hora_inicio: str,
    hora_fim: Optional[str] = None
) -> str:
    """
    Programa a execução de uma atividade cadastrada para um dia específico.
    Utiliza DocumentReference para vincular à atividade original.
    """
    ativ_ref = db.collection("atividades_cadastradas").document(atividade_id)
    ativ_doc = ativ_ref.get()

    if not ativ_doc.exists:
        raise ValueError("Atividade não encontrada.")

    dados = {
        "atividade_ref": ativ_ref,
        "nome_atividade": ativ_doc.to_dict().get("nome"),
        "categoria_nome": ativ_doc.to_dict().get("categoria_nome"),
        "data": data,
        "hora_inicio": hora_inicio,
        "hora_fim": hora_fim or "",
        "concluido": False,
        "criado_em": firestore.SERVER_TIMESTAMP
    }
    _, doc_ref = db.collection("rotina_agendada").add(dados)
    return doc_ref.id


# =====================================================================
# 3. VISÃO DO DIA (MERGE: ROTINA + PONTUAIS + GOOGLE CALENDAR)
# =====================================================================

def obter_agenda_unificada_do_dia(data: str) -> Dict[str, Any]:
    """
    Consolida tudo o que você tem agendado para o dia:
    - Atividades de rotina
    - Compromissos pontuais (avulsos)
    - Eventos do Google Agenda (somente leitura)
    """
    # 1. Rotina agendada no Firestore
    rotinas = db.collection("rotina_agendada").where("data", "==", data).stream()
    lista_rotinas = [
        {"id": r.id, **r.to_dict(), "tipo": "rotina"} for r in rotinas
    ]

    # 2. Compromissos pontuais no Firestore
    pontuais = db.collection("compromissos_pontuais").where("data", "==", data).stream()
    lista_pontuais = [
        {"id": p.id, **p.to_dict(), "tipo": "pontual"} for p in pontuais
    ]

    # 3. Google Agenda (via google_calendar.py)
    from google_calendar import listar_eventos_do_dia
    eventos_google = listar_eventos_do_dia(data)

    return {
        "data": data,
        "rotina": lista_rotinas,
        "pontuais": lista_pontuais,
        "google_agenda": eventos_google,
        "total_itens": len(lista_rotinas) + len(lista_pontuais) + len(eventos_google)
    }`;

  const REQUIREMENTS_CODE = `firebase-admin>=6.5.0
pyTelegramBotAPI>=4.15.0
python-dotenv>=1.0.0
google-cloud-firestore>=2.14.0
google-api-python-client>=2.108.0
google-auth-httplib2>=0.1.1
google-auth-oauthlib>=1.1.0
icalendar>=5.0.10`;

  const CLOUDRUN_GUIDE = `# Instruções para Executar e Hospedar no Google Cloud Run (Free Tier)

1. Executar Localmente no seu Computador:
   pip install -r requirements.txt
   python bot.py

2. Deploy no Google Cloud Run:
   - Crie um Dockerfile:
     FROM python:3.11-slim
     WORKDIR /app
     COPY requirements.txt .
     RUN pip install --no-cache-dir -r requirements.txt
     COPY . .
     CMD ["python", "bot.py"]

   - O arquivo chave-firebase.json deve estar na pasta raiz ou no Secret Manager.
   - O arquivo credentials.json / token.json do Google Calendar fica na pasta raiz.`;

  const getCurrentCode = () => {
    switch (activeFile) {
      case 'database':
        return DATABASE_CODE;
      case 'bot':
        return BOT_CODE;
      case 'google_calendar':
        return GOOGLE_CALENDAR_CODE;
      case 'agendamento':
        return AGENDAMENTO_CODE;
      case 'requirements':
        return REQUIREMENTS_CODE;
      case 'cloudrun':
        return CLOUDRUN_GUIDE;
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getCurrentCode());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-[#0d0d0d] rounded-2xl border border-[#222] p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-[#1a1a1a] text-amber-400 border border-[#2a2a2a]">
              <FileCode className="w-5 h-5" />
            </div>
            <h2 className="text-xl font-serif italic text-white">
              Códigos Python Prontos para Uso
            </h2>
          </div>
          <p className="text-xs text-[#888] mt-1.5 leading-relaxed">
            Arquivos prontos para criar no seu computador: <code className="text-amber-400 bg-[#161616] border border-[#262626] px-1.5 py-0.5 rounded font-mono">database.py</code>, <code className="text-amber-400 bg-[#161616] border border-[#262626] px-1.5 py-0.5 rounded font-mono">bot.py</code>, <code className="text-emerald-400 bg-[#161616] border border-[#262626] px-1.5 py-0.5 rounded font-mono">google_calendar.py</code>, <code className="text-purple-400 bg-[#161616] border border-[#262626] px-1.5 py-0.5 rounded font-mono">agendamento_service.py</code> e <code className="text-amber-400 bg-[#161616] border border-[#262626] px-1.5 py-0.5 rounded font-mono">requirements.txt</code>.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handleCopy}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-black shadow-xs transition-all cursor-pointer"
          >
            {copied ? <Check className="w-4 h-4 text-black" /> : <Copy className="w-4 h-4 text-black" />}
            <span>{copied ? 'Copiado para Área de Transferência!' : 'Copiar Arquivo Selecionado'}</span>
          </button>
        </div>
      </div>

      {/* Tab bar for files */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
        {[
          { id: 'database' as const, label: 'database.py (Firestore CRUD)' },
          { id: 'bot' as const, label: 'bot.py (Telegram Bot)' },
          { id: 'google_calendar' as const, label: 'google_calendar.py (Google Agenda)' },
          { id: 'agendamento' as const, label: 'agendamento_service.py (Rotina + Pontuais)' },
          { id: 'requirements' as const, label: 'requirements.txt' },
          { id: 'cloudrun' as const, label: 'Guia do Computador & Cloud Run' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveFile(tab.id)}
            className={`px-3.5 py-2.5 rounded-xl text-xs font-mono font-medium transition-all cursor-pointer whitespace-nowrap ${
              activeFile === tab.id
                ? 'bg-[#181818] text-amber-300 border border-amber-500/40 shadow-xs'
                : 'bg-[#0e0e0e] text-[#777] border border-[#222] hover:border-[#333] hover:text-[#ccc]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Code Box */}
      <div className="relative rounded-2xl overflow-hidden border border-[#222] bg-[#080808] text-[#d4d4d4] shadow-2xl">
        <div className="bg-[#121212] px-4 py-3 flex items-center justify-between border-b border-[#222]">
          <span className="font-mono text-xs text-amber-300 flex items-center gap-2">
            <Terminal className="w-3.5 h-3.5 text-amber-400" />
            {activeFile === 'database' && 'database.py'}
            {activeFile === 'bot' && 'bot.py'}
            {activeFile === 'requirements' && 'requirements.txt'}
            {activeFile === 'cloudrun' && 'README.md'}
          </span>
          <button
            onClick={handleCopy}
            className="text-xs text-[#888] hover:text-white flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#1a1a1a] border border-[#2a2a2a] hover:bg-[#222] transition-colors cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copiado' : 'Copiar'}</span>
          </button>
        </div>

        <pre className="p-5 overflow-x-auto text-xs font-mono leading-relaxed text-[#d4d4d4] max-h-[550px]">
          {getCurrentCode()}
        </pre>
      </div>
    </div>
  );
};
