import React from 'react';
import {
  BarChart3,
  Calendar,
  Layers,
  Target,
  Bot,
  Code2,
  Sparkles,
  Download
} from 'lucide-react';

export type AppTab = 'analytics' | 'calendario' | 'atividades' | 'metas' | 'simulador' | 'codigo';

interface NavbarProps {
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
  categoriesCount: number;
  activitiesCount: number;
  scoreGeral: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  categoriesCount,
  activitiesCount,
  scoreGeral
}) => {
  const tabs = [
    {
      id: 'analytics' as const,
      label: 'Painel & Histórico',
      icon: BarChart3,
      badge: 'Mensal/Anual'
    },
    {
      id: 'calendario' as const,
      label: 'Agenda do Dia',
      icon: Calendar,
      badge: 'Hoje'
    },
    {
      id: 'atividades' as const,
      label: 'Atividades & Categorias',
      icon: Layers,
      badge: `${activitiesCount}`
    },
    {
      id: 'metas' as const,
      label: 'Metas & Proporção de Pesos',
      icon: Target,
      badge: `${scoreGeral}/100`
    },
    {
      id: 'simulador' as const,
      label: 'Simulador Telegram Bot',
      icon: Bot,
      badge: 'Comandos'
    },
    {
      id: 'codigo' as const,
      label: 'Scripts Python',
      icon: Code2,
      badge: 'Firestore'
    }
  ];

  return (
    <header className="border-b border-[#222] bg-[#0d0d0d] sticky top-0 z-40 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Info */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#1a1a1a] border border-[#333] flex items-center justify-center text-[11px] text-amber-500 font-mono font-bold shadow-xs">
              <Sparkles className="w-4 h-4 text-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-white font-serif italic text-base sm:text-lg">
                  Gestão de Rotina & Metas
                </span>
                <span className="hidden md:inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-[#16231a] text-emerald-400 border border-emerald-900/50">
                  Firestore Conectado
                </span>
              </div>
              <p className="text-[11px] text-[#666] hidden sm:block font-mono">
                Análise Mensal/Semestral/Anual • 7 Pilares • Telegram Sync
              </p>
            </div>
          </div>

          {/* Status Indicators */}
          <div className="flex items-center gap-2">
            <div className="hidden md:flex items-center gap-4 text-xs font-mono text-[#888] bg-[#121212] px-3.5 py-1.5 rounded-lg border border-[#222]">
              <span className="flex items-center gap-1.5 text-xs text-[#aaa]">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                {categoriesCount} Pilares
              </span>
              <span className="text-[#333]">|</span>
              <span className="flex items-center gap-1.5 text-xs text-[#aaa]">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
                {activitiesCount} Atividades
              </span>
              <span className="text-[#333]">|</span>
              <span className="flex items-center gap-1.5 text-xs text-amber-400 font-bold font-mono">
                Score: {scoreGeral}/100
              </span>
            </div>

            {/* Botão Baixar ZIP */}
            <a
              href="/frontend.zip"
              download="frontend.zip"
              id="btn-download-frontend-zip"
              className="px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-semibold text-xs flex items-center gap-2 transition-all shadow-xs cursor-pointer"
              title="Baixar pasta frontend completa compactada em .zip"
            >
              <Download className="w-4 h-4" />
              <span className="font-sans font-bold">Baixar frontend.zip</span>
            </a>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex overflow-x-auto space-x-1.5 py-1.5 no-scrollbar border-t border-[#1a1a1a]">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`nav-tab-${tab.id}`}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-[#181818] text-white border border-[#333] shadow-xs'
                    : 'text-[#888] hover:text-white hover:bg-[#121212] border border-transparent'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-[#666]'}`} />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span
                    className={`text-[10px] font-mono px-1.5 py-0.5 rounded transition-colors ${
                      isActive
                        ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                        : 'bg-[#202020] text-[#777] border border-[#2a2a2a]'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
