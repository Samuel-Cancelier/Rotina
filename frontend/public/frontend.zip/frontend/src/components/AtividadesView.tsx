import React, { useState } from 'react';
import { Categoria, AtividadeCadastrada } from '../types';
import {
  Plus,
  Filter,
  FolderOpen,
  Activity,
  CheckCircle2,
  Repeat,
  Zap,
  Target,
  FileCode,
  Sparkles,
  Info,
  Trash2
} from 'lucide-react';

interface AtividadesViewProps {
  categorias: Categoria[];
  atividades: AtividadeCadastrada[];
  onAddAtividade: (nova: Omit<AtividadeCadastrada, 'id' | 'criado_em'>) => void;
  onAddCategoria: (nova: Omit<Categoria, 'id' | 'criado_em'>) => void;
  onDeleteAtividade: (id: string) => void;
}

export const AtividadesView: React.FC<AtividadesViewProps> = ({
  categorias,
  atividades,
  onAddAtividade,
  onAddCategoria,
  onDeleteAtividade
}) => {
  const [selectedCategoria, setSelectedCategoria] = useState<string>('todas');
  const [showNovaAtividadeModal, setShowNovaAtividadeModal] = useState(false);
  const [showNovaCategoriaModal, setShowNovaCategoriaModal] = useState(false);
  const [selectedAtividadeForJson, setSelectedAtividadeForJson] = useState<AtividadeCadastrada | null>(null);

  // Form states for Nova Atividade
  const [nomeAtividade, setNomeAtividade] = useState('');
  const [categoriaId, setCategoriaId] = useState(categorias[0]?.id || '');
  const [unidadeAtividade, setUnidadeAtividade] = useState(categorias[0]?.unidade_padrao || '');
  const [recorrente, setRecorrente] = useState(true);
  const [afetaMeta, setAfetaMeta] = useState(true);
  const [extraKey, setExtraKey] = useState('');
  const [extraValue, setExtraValue] = useState('');

  // Form states for Nova Categoria
  const [nomeCategoria, setNomeCategoria] = useState('');
  const [unidadePadrao, setUnidadePadrao] = useState('minutos');
  const [pesoScore, setPesoScore] = useState(25);

  // Calculate sum of category weights
  const pesoTotal = categorias.reduce((acc, curr) => acc + (Number(curr.peso_no_score) || 0), 0);

  // Update default unit when category changes
  const handleCategoriaChange = (catId: string) => {
    setCategoriaId(catId);
    const cat = categorias.find((c) => c.id === catId);
    if (cat) {
      setUnidadeAtividade(cat.unidade_padrao);
    }
  };

  const handleCreateAtividade = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nomeAtividade.trim() || !categoriaId) return;

    const cat = categorias.find((c) => c.id === categoriaId);
    const camposExtras: Record<string, any> = {};
    if (extraKey.trim() && extraValue.trim()) {
      camposExtras[extraKey.trim()] = extraValue.trim();
    }

    onAddAtividade({
      nome: nomeAtividade.trim(),
      categoria_id: categoriaId,
      categoria_nome: cat?.nome || 'Geral',
      recorrente,
      unidade: unidadeAtividade.trim() || cat?.unidade_padrao || 'un',
      afeta_meta: afetaMeta,
      campos_extras: camposExtras
    });

    // Reset
    setNomeAtividade('');
    setExtraKey('');
    setExtraValue('');
    setShowNovaAtividadeModal(false);
  };

  const handleCreateCategoria = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nomeCategoria.trim()) return;

    onAddCategoria({
      nome: nomeCategoria.trim(),
      unidade_padrao: unidadePadrao.trim().toLowerCase(),
      peso_no_score: Number(pesoScore) || 10,
      cor: '#3B82F6',
      icone: 'Folder'
    });

    setNomeCategoria('');
    setUnidadePadrao('minutos');
    setPesoScore(20);
    setShowNovaCategoriaModal(false);
  };

  // Filter activities
  const filteredAtividades = atividades.filter((ativ) => {
    if (selectedCategoria === 'todas') return true;
    return ativ.categoria_id === selectedCategoria;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner: Weight distribution and actions */}
      <div className="bg-[#0d0d0d] rounded-xl border border-[#222] p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono uppercase tracking-widest text-amber-500 font-bold">
                Coleção Firestore
              </span>
              <span className="text-xs bg-[#1a1a1a] border border-[#333] text-amber-400 font-mono px-2 py-0.5 rounded">
                atividades_cadastradas ({atividades.length})
              </span>
            </div>
            <h2 className="text-xl font-serif italic text-white mt-1">
              Catálogo de Hábitos & Rotina
            </h2>
            <p className="text-xs sm:text-sm text-[#888] mt-1">
              Cada atividade é vinculada a uma categoria existente no Firestore via{' '}
              <code className="bg-[#161616] text-amber-400 border border-[#262626] px-1.5 py-0.5 rounded text-xs font-mono">
                categoria_id
              </code>{' '}
              e <code className="bg-[#161616] text-amber-400 border border-[#262626] px-1.5 py-0.5 rounded text-xs font-mono">categoria_ref</code>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              id="btn-abrir-nova-categoria"
              onClick={() => setShowNovaCategoriaModal(true)}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium text-[#ccc] bg-[#141414] border border-[#262626] hover:bg-[#1a1a1a] hover:text-white transition-colors"
            >
              <FolderOpen className="w-4 h-4 text-amber-500" />
              <span>Nova Categoria</span>
            </button>

            <button
              id="btn-abrir-nova-atividade"
              onClick={() => {
                if (categorias.length > 0 && !categoriaId) {
                  setCategoriaId(categorias[0].id);
                  setUnidadeAtividade(categorias[0].unidade_padrao);
                }
                setShowNovaAtividadeModal(true);
              }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold text-black bg-amber-500 hover:bg-amber-400 transition-all shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Cadastrar Atividade</span>
            </button>
          </div>
        </div>

        {/* Weights Summary Bar */}
        <div className="mt-5 pt-4 border-t border-[#1c1c1c]">
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="font-medium text-[#aaa] flex items-center gap-1.5">
              <Target className="w-3.5 h-3.5 text-amber-500" />
              Distribuição de Peso das Categorias no Score Geral
            </span>
            <span className={`font-mono text-xs ${pesoTotal === 100 ? 'text-emerald-400' : 'text-amber-400'}`}>
              Soma: {pesoTotal}% {pesoTotal === 100 ? '(Equilibrado 100%)' : '(Ajuste para 100%)'}
            </span>
          </div>

          <div className="h-2 w-full bg-[#1a1a1a] rounded-full overflow-hidden flex">
            {categorias.map((cat, idx) => {
              const bgColors = ['bg-amber-500', 'bg-emerald-500', 'bg-blue-500', 'bg-purple-500', 'bg-rose-500', 'bg-cyan-500'];
              const colorClass = bgColors[idx % bgColors.length];
              return (
                <div
                  key={cat.id}
                  style={{ width: `${Math.min(cat.peso_no_score, 100)}%` }}
                  className={`${colorClass} h-full transition-all`}
                  title={`${cat.nome}: ${cat.peso_no_score}%`}
                />
              );
            })}
          </div>

          <div className="flex flex-wrap gap-2.5 mt-3">
            {categorias.map((cat) => {
              const countInCat = atividades.filter(a => a.categoria_id === cat.id).length;
              return (
                <div key={cat.id} className="inline-flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-md border border-[#222] bg-[#121212] text-[#ccc]">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                  <span className="font-medium text-white">{cat.nome}</span>
                  <span className="text-[#777] font-mono text-[11px]">({cat.peso_no_score}% • {cat.unidade_padrao})</span>
                  <span className="ml-1 bg-[#1c1c1c] text-[#aaa] border border-[#282828] px-1.5 py-0.2 rounded text-[10px] font-mono">
                    {countInCat} ativ.
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Filter and Content */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar w-full sm:w-auto">
          <Filter className="w-4 h-4 text-[#555] shrink-0" />
          <button
            id="filtro-cat-todas"
            onClick={() => setSelectedCategoria('todas')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
              selectedCategoria === 'todas'
                ? 'bg-[#1e1e1e] text-white border border-[#333] shadow-xs'
                : 'bg-[#101010] text-[#777] border border-[#222] hover:bg-[#161616] hover:text-[#ccc]'
            }`}
          >
            Todas ({atividades.length})
          </button>
          {categorias.map((cat) => (
            <button
              key={cat.id}
              id={`filtro-cat-${cat.id}`}
              onClick={() => setSelectedCategoria(cat.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
                selectedCategoria === cat.id
                  ? 'bg-[#1e1e1e] text-white border border-[#333] shadow-xs'
                  : 'bg-[#101010] text-[#777] border border-[#222] hover:bg-[#161616] hover:text-[#ccc]'
              }`}
            >
              {cat.nome} ({atividades.filter((a) => a.categoria_id === cat.id).length})
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Activities */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredAtividades.map((ativ) => {
          return (
            <div
              key={ativ.id}
              id={`card-atividade-${ativ.id}`}
              className="bg-[#111] rounded-xl border border-[#1f1f1f] p-4.5 hover:border-[#333] hover:shadow-[0_4px_20px_rgba(0,0,0,0.4)] transition-all flex flex-col justify-between"
            >
              <div>
                {/* Header: Category Badge & Recurrence */}
                <div className="flex items-center justify-between gap-2 mb-2.5">
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-[#161616] text-[#ccc] border border-[#262626]">
                    <FolderOpen className="w-3 h-3 text-amber-500" />
                    <span className="truncate max-w-[140px]">{ativ.categoria_nome}</span>
                  </span>

                  <span
                    className={`inline-flex items-center gap-1 text-[11px] font-mono px-2 py-0.5 rounded-full ${
                      ativ.recorrente
                        ? 'bg-[#142319] text-emerald-400 border border-emerald-900/50'
                        : 'bg-[#1a1a1a] text-[#888] border border-[#2a2a2a]'
                    }`}
                  >
                    {ativ.recorrente ? <Repeat className="w-3 h-3" /> : <Zap className="w-3 h-3" />}
                    {ativ.recorrente ? 'Recorrente' : 'Pontual'}
                  </span>
                </div>

                {/* Activity Name */}
                <h3 className="text-lg font-serif italic text-white mb-2 leading-snug">
                  {ativ.nome}
                </h3>

                {/* Metadata badges */}
                <div className="space-y-2 text-xs text-[#888]">
                  <div className="flex items-center justify-between">
                    <span className="text-[#666]">Unidade de Medida:</span>
                    <span className="font-mono text-[11px] text-[#e5e5e5] bg-[#181818] px-2 py-0.5 rounded border border-[#262626]">
                      {ativ.unidade}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-[#666]">Impacto no Score:</span>
                    <span
                      className={`font-medium flex items-center gap-1 ${
                        ativ.afeta_meta ? 'text-emerald-400' : 'text-[#666]'
                      }`}
                    >
                      {ativ.afeta_meta ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                          <span>Pontua na Meta</span>
                        </>
                      ) : (
                        'Apenas Histórico'
                      )}
                    </span>
                  </div>

                  {ativ.campos_extras && Object.keys(ativ.campos_extras).length > 0 && (
                    <div className="pt-2 border-t border-[#1c1c1c] flex flex-wrap gap-1">
                      {Object.entries(ativ.campos_extras).map(([k, v]) => (
                        <span
                          key={k}
                          className="text-[10px] font-mono bg-[#161616] text-[#aaa] border border-[#262626] px-1.5 py-0.5 rounded"
                        >
                          {k}: {String(v)}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Card Footer: Firestore Reference Link & Actions */}
              <div className="mt-4 pt-3 border-t border-[#1c1c1c] flex items-center justify-between text-xs">
                <span
                  className="font-mono text-[10px] text-[#555] truncate max-w-[130px]"
                  title={`ID do Documento: ${ativ.id}`}
                >
                  id: {ativ.id}
                </span>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setSelectedAtividadeForJson(ativ)}
                    className="p-1.5 text-[#777] hover:text-amber-400 hover:bg-[#1a1a1a] rounded transition-colors"
                    title="Ver JSON do Documento Firestore"
                  >
                    <FileCode className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onDeleteAtividade(ativ.id)}
                    className="p-1.5 text-[#666] hover:text-rose-400 hover:bg-rose-950/30 rounded transition-colors"
                    title="Excluir Atividade"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}

        {filteredAtividades.length === 0 && (
          <div className="col-span-full py-12 text-center bg-[#0d0d0d] rounded-xl border border-dashed border-[#262626] p-8">
            <Activity className="w-10 h-10 text-[#444] mx-auto mb-3" />
            <p className="text-white font-serif italic text-lg">Nenhuma atividade nesta categoria.</p>
            <p className="text-[#777] text-xs mt-1">
              Clique em "Cadastrar Atividade" acima ou use o bot do Telegram com{' '}
              <code className="bg-[#161616] text-amber-400 px-1 py-0.5 rounded font-mono border border-[#262626]">
                /nova_atividade
              </code>.
            </p>
          </div>
        )}
      </div>

      {/* Modal: Nova Atividade */}
      {showNovaAtividadeModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#111] text-[#d4d4d4] rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-[#262626]">
            <div className="flex items-center justify-between pb-3 border-b border-[#222]">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-[#1a1a1a] text-amber-400 border border-[#333]">
                  <Activity className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-serif italic text-white">Cadastrar Nova Atividade</h3>
                  <p className="text-xs text-[#777] font-mono">Coleção: atividades_cadastradas</p>
                </div>
              </div>
              <button
                onClick={() => setShowNovaAtividadeModal(false)}
                className="text-[#666] hover:text-white text-xl font-semibold transition-colors"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleCreateAtividade} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-medium text-[#aaa] mb-1">
                  Nome da Atividade *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Treino de Musculação, Corrida 10km, Leitura"
                  value={nomeAtividade}
                  onChange={(e) => setNomeAtividade(e.target.value)}
                  className="w-full text-sm bg-[#161616] border border-[#2a2a2a] text-white rounded-lg px-3 py-2 focus:border-amber-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#aaa] mb-1">
                  Categoria Vinculada (DocumentReference) *
                </label>
                <select
                  value={categoriaId}
                  onChange={(e) => handleCategoriaChange(e.target.value)}
                  className="w-full text-sm bg-[#161616] border border-[#2a2a2a] text-white rounded-lg px-3 py-2 focus:border-amber-500 focus:outline-hidden"
                >
                  {categorias.map((cat) => (
                    <option key={cat.id} value={cat.id} className="bg-[#161616] text-white">
                      {cat.nome} (Padrão: {cat.unidade_padrao} | Peso: {cat.peso_no_score}%)
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-[#777] mt-1 flex items-center gap-1 font-mono">
                  <Info className="w-3 h-3 text-amber-500" />
                  Salva <code className="text-amber-400">categoria_id</code> e ref NoSQL{' '}
                  <code className="text-amber-400">categorias/{categoriaId}</code>.
                </p>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#aaa] mb-1">
                  Unidade de Medida
                </label>
                <input
                  type="text"
                  placeholder="Ex: minutos, km, páginas, repetições"
                  value={unidadeAtividade}
                  onChange={(e) => setUnidadeAtividade(e.target.value)}
                  className="w-full text-sm bg-[#161616] border border-[#2a2a2a] text-white rounded-lg px-3 py-2 focus:border-amber-500 focus:outline-hidden"
                />
                <span className="text-[11px] text-[#666]">
                  Herdada automaticamente da categoria, mas pode ser personalizada.
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-1">
                <label className="flex items-center gap-2 p-3 rounded-lg border border-[#222] bg-[#141414] cursor-pointer hover:bg-[#1a1a1a]">
                  <input
                    type="checkbox"
                    checked={recorrente}
                    onChange={(e) => setRecorrente(e.target.checked)}
                    className="w-4 h-4 rounded accent-amber-500"
                  />
                  <div>
                    <span className="text-xs font-semibold text-white block">Recorrente</span>
                    <span className="text-[10px] text-[#777] block">Faz parte da rotina habitual</span>
                  </div>
                </label>

                <label className="flex items-center gap-2 p-3 rounded-lg border border-[#222] bg-[#141414] cursor-pointer hover:bg-[#1a1a1a]">
                  <input
                    type="checkbox"
                    checked={afetaMeta}
                    onChange={(e) => setAfetaMeta(e.target.checked)}
                    className="w-4 h-4 rounded accent-amber-500"
                  />
                  <div>
                    <span className="text-xs font-semibold text-white block">Afeta Meta</span>
                    <span className="text-[10px] text-[#777] block">Soma para o score da categoria</span>
                  </div>
                </label>
              </div>

              <div className="pt-2 border-t border-[#1f1f1f]">
                <label className="block text-xs font-medium text-[#aaa] mb-1">
                  Campos Extras Opcionais (Map/Dict)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="Chave (ex: foco)"
                    value={extraKey}
                    onChange={(e) => setExtraKey(e.target.value)}
                    className="text-xs bg-[#161616] border border-[#2a2a2a] text-white rounded-lg px-2.5 py-1.5 focus:border-amber-500 focus:outline-hidden"
                  />
                  <input
                    type="text"
                    placeholder="Valor (ex: hipertrofia)"
                    value={extraValue}
                    onChange={(e) => setExtraValue(e.target.value)}
                    className="text-xs bg-[#161616] border border-[#2a2a2a] text-white rounded-lg px-2.5 py-1.5 focus:border-amber-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-[#1f1f1f]">
                <button
                  type="button"
                  onClick={() => setShowNovaAtividadeModal(false)}
                  className="px-4 py-2 rounded-lg text-xs font-medium text-[#888] hover:text-white hover:bg-[#1a1a1a] transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg text-xs font-semibold text-black bg-amber-500 hover:bg-amber-400 transition-all shadow-xs"
                >
                  Salvar Atividade no Firestore
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Nova Categoria */}
      {showNovaCategoriaModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#111] text-[#d4d4d4] rounded-2xl max-w-md w-full p-6 shadow-2xl border border-[#262626]">
            <div className="flex items-center justify-between pb-3 border-b border-[#222]">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-[#1a1a1a] text-amber-400 border border-[#333]">
                  <FolderOpen className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-serif italic text-white">Nova Categoria</h3>
                  <p className="text-xs text-[#777] font-mono">Coleção: categorias</p>
                </div>
              </div>
              <button
                onClick={() => setShowNovaCategoriaModal(false)}
                className="text-[#666] hover:text-white text-xl font-semibold transition-colors"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleCreateCategoria} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-medium text-[#aaa] mb-1">
                  Nome da Categoria *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Trabalho Profissional, Finanças, Saúde"
                  value={nomeCategoria}
                  onChange={(e) => setNomeCategoria(e.target.value)}
                  className="w-full text-sm bg-[#161616] border border-[#2a2a2a] text-white rounded-lg px-3 py-2 focus:border-amber-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[#aaa] mb-1">
                    Unidade Padrão *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="minutos, km, horas"
                    value={unidadePadrao}
                    onChange={(e) => setUnidadePadrao(e.target.value)}
                    className="w-full text-sm bg-[#161616] border border-[#2a2a2a] text-white rounded-lg px-3 py-2 focus:border-amber-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#aaa] mb-1">
                    Peso no Score (0-100) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    required
                    value={pesoScore}
                    onChange={(e) => setPesoScore(Number(e.target.value))}
                    className="w-full text-sm bg-[#161616] border border-[#2a2a2a] text-white rounded-lg px-3 py-2 focus:border-amber-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-[#1f1f1f]">
                <button
                  type="button"
                  onClick={() => setShowNovaCategoriaModal(false)}
                  className="px-4 py-2 rounded-lg text-xs font-medium text-[#888] hover:text-white hover:bg-[#1a1a1a] transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg text-xs font-semibold text-black bg-amber-500 hover:bg-amber-400 transition-all shadow-xs"
                >
                  Criar Categoria
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Inspecionar JSON Firestore */}
      {selectedAtividadeForJson && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#0f0f0f] text-[#d4d4d4] rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-[#2a2a2a]">
            <div className="flex items-center justify-between pb-3 border-b border-[#222]">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-medium text-white font-mono">
                  Documento: {selectedAtividadeForJson.nome}
                </h3>
              </div>
              <button
                onClick={() => setSelectedAtividadeForJson(null)}
                className="text-[#666] hover:text-white font-semibold transition-colors"
              >
                &times;
              </button>
            </div>

            <div className="mt-4">
              <p className="text-xs text-[#888] mb-2 font-mono">
                Path: <code className="text-amber-400">/atividades_cadastradas/{selectedAtividadeForJson.id}</code>
              </p>
              <pre className="text-xs font-mono bg-[#070707] p-3 rounded-lg border border-[#222] overflow-x-auto text-emerald-400">
{JSON.stringify(
  {
    _id: selectedAtividadeForJson.id,
    nome: selectedAtividadeForJson.nome,
    categoria_id: selectedAtividadeForJson.categoria_id,
    categoria_ref: `DocumentReference(categorias/${selectedAtividadeForJson.categoria_id})`,
    categoria_nome: selectedAtividadeForJson.categoria_nome,
    unidade: selectedAtividadeForJson.unidade,
    recorrente: selectedAtividadeForJson.recorrente,
    afeta_meta: selectedAtividadeForJson.afeta_meta,
    campos_extras: selectedAtividadeForJson.campos_extras,
    criado_em: selectedAtividadeForJson.criado_em || 'SERVER_TIMESTAMP'
  },
  null,
  2
)}
              </pre>
            </div>

            <div className="mt-4 flex justify-end">
              <button
                onClick={() => setSelectedAtividadeForJson(null)}
                className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-[#1e1e1e] hover:bg-[#282828] text-white border border-[#333]"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
