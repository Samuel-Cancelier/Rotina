import React, { useState, useRef, useEffect } from 'react';
import { Categoria, AtividadeCadastrada } from '../types';
import { Send, Bot, RotateCcw, Check, Sparkles, Terminal } from 'lucide-react';

interface TelegramSimulatorProps {
  categorias: Categoria[];
  atividades: AtividadeCadastrada[];
  onAddAtividadeFromBot: (nova: Omit<AtividadeCadastrada, 'id' | 'criado_em'>) => string;
  onAddCategoriaFromBot: (nome: string, unidade: string, peso: number) => string;
  onRegistrarFeito?: (catNome: string, ativNome: string, valor: number) => void;
  onAgendarPontual?: (hora: string, titulo: string) => void;
}

interface Message {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  time: string;
  buttons?: Array<{
    label: string;
    callbackData: string;
    action: () => void;
  }>;
}

export const TelegramSimulator: React.FC<TelegramSimulatorProps> = ({
  categorias,
  atividades,
  onAddAtividadeFromBot,
  onAddCategoriaFromBot,
  onRegistrarFeito,
  onAgendarPontual
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm1',
      sender: 'bot',
      text: `👋 *Sistema de Gestão de Rotina & Metas (Simulador Telegram)*\n\nComandos disponíveis:\n📅 \`/agenda\` - Mostra a agenda unificada do dia\n✅ \`/feito corrida Parque 5\` - Lança diretamente na atividade e categoria\n➕ \`/nova_atividade Parque\` - Cadastra nova atividade com botões de categoria\n⚡ \`/agendar 14:30 Dentista\` - Compromisso pontual do dia\n📊 \`/score\` - Ver Score Geral e indicador de ritmo`,
      time: '12:00'
    }
  ]);

  const [inputVal, setInputVal] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const addBotMessage = (text: string, buttons?: Message['buttons']) => {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setMessages((prev) => [
      ...prev,
      {
        id: `bot_${Date.now()}_${Math.random()}`,
        sender: 'bot',
        text,
        time,
        buttons
      }
    ]);
  };

  const addUserMessage = (text: string) => {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setMessages((prev) => [
      ...prev,
      {
        id: `usr_${Date.now()}_${Math.random()}`,
        sender: 'user',
        text,
        time
      }
    ]);
  };

  const handleCommand = (cmd: string) => {
    const cleanCmd = cmd.trim();
    if (!cleanCmd) return;
    addUserMessage(cleanCmd);

    // 1. /start ou /help
    if (cleanCmd === '/start' || cleanCmd === '/help') {
      setTimeout(() => {
        addBotMessage(
          `👋 *Planejador de Rotina, Metas & Score*\n\n` +
            `Comandos principais:\n` +
            `📅 \`/agenda\` - Visão unificada do dia\n` +
            `✅ \`/feito [categoria] [atividade] [quantidade]\` - Ex: \`/feito corrida Parque 5\`\n` +
            `⚡ \`/agendar <hh:mm> <descricao>\` - Ex: \`/agendar 14:30 Dentista\`\n` +
            `➕ \`/nova_atividade [nome]\` - Ex: \`/nova_atividade Parque\`\n` +
            `📊 \`/score\` - Relatório de desempenho semanal`
        );
      }, 300);
      return;
    }

    // 2. /score
    if (cleanCmd === '/score') {
      setTimeout(() => {
        addBotMessage(
          `📊 *RELATÓRIO DE METAS & SCORE SEMANAL*\n\n` +
            `🏆 *Score Geral:* \`88/100\`\n` +
            `⏱️ *Semana Decorrida:* \`57.1%\` (Dia 4 de 7)\n\n` +
            `*Desempenho por Categoria:*\n` +
            `• *Corrida* (Peso: 25%) - \`15.0/20.0 km\` | Score: 100% (🟢 No ritmo)\n` +
            `• *Estudos* (Peso: 20%) - \`320/360 min\` | Score: 89% (🟢 No ritmo)\n` +
            `• *Futsal* (Peso: 20%) - \`2/2 sessões\` | Score: 100% (🟢 No ritmo)\n` +
            `• *Leitura* (Peso: 15%) - \`60/80 págs\` | Score: 75% (🟢 No ritmo)\n` +
            `• *Trabalho* (Informativo - 0% peso) - \`38.0 horas\` (Ref: 40h/sem)`
        );
      }, 300);
      return;
    }

    // 3. /agenda
    if (cleanCmd === '/agenda') {
      setTimeout(() => {
        addBotMessage(
          `📅 *AGENDA DE HOJE (07/09/2026)*\n\n` +
            `🟢 *Google Agenda:*\n` +
            `• \`10:00\` - *Meet Alinhamento Squad*\n\n` +
            `🔵 *Rotina Planejada:*\n` +
            `• ✅ \`06:30\` - *Corrida no Parque* (Corrida)\n` +
            `• ⏳ \`09:00\` - *Trabalho Empresa* (Trabalho / Carreira)\n` +
            `• ⏳ \`21:30\` - *Leitura Código Limpo* (Leitura)\n\n` +
            `🟣 *Compromissos Pontuais:*\n` +
            `• ⏳ \`14:30\` - *Dentista - Revisão Semestral*`
        );
      }, 300);
      return;
    }

    // 4. /agendar <hh:mm> <descricao>
    if (cleanCmd.startsWith('/agendar')) {
      const partes = cleanCmd.split(' ');
      if (partes.length < 2) {
        setTimeout(() => {
          addBotMessage(`⚠️ Use: \`/agendar <hh:mm> <descricao>\`\nExemplo: \`/agendar 14:30 Dentista\``);
        }, 300);
        return;
      }

      const hora = partes[1].includes(':') ? partes[1] : 'A definir';
      const titulo = partes[1].includes(':') ? partes.slice(2).join(' ') : partes.slice(1).join(' ');

      if (onAgendarPontual) {
        onAgendarPontual(hora, titulo || 'Compromisso Avulso');
      }

      setTimeout(() => {
        addBotMessage(
          `✅ *Compromisso agendado para hoje!*\n\n` +
            `📌 *${titulo || 'Lembrete'}*\n` +
            `⏰ Horário: \`${hora}\`\n` +
            `ℹ️ _Salvo sem categoria apenas como lembrete na sua /agenda._`
        );
      }, 300);
      return;
    }

    // 5. /nova_atividade [nome]
    if (cleanCmd.startsWith('/nova_atividade')) {
      const partes = cleanCmd.split(' ');
      const nomeAtiv = partes.length > 1 ? partes.slice(1).join(' ') : 'Atividade';

      const botoes = categorias.map((cat) => ({
        label: `${cat.nome} (${cat.peso_no_score}%)`,
        callbackData: `cat_${cat.id}`,
        action: () => {
          onAddAtividadeFromBot({
            nome: nomeAtiv,
            categoria_id: cat.id,
            categoria_nome: cat.nome,
            unidade: cat.unidade_padrao,
            recorrente: true,
            afeta_meta: true
          });
          addBotMessage(
            `🎉 *Atividade cadastrada com sucesso!*\n\n` +
              `📌 *Nome:* ${nomeAtiv}\n` +
              `📁 *Categoria:* ${cat.nome}\n` +
              `📏 *Unidade:* \`${cat.unidade_padrao}\`\n\n` +
              `_Agora você pode lançar: \`/feito ${cat.nome.toLowerCase().split(' ')[0]} ${nomeAtiv} 5\`_`
          );
        }
      }));

      setTimeout(() => {
        addBotMessage(
          `🎯 Cadastrando a atividade: *${nomeAtiv}*\n\nSelecione a qual dos Pilares ela pertencerá:`,
          botoes
        );
      }, 300);
      return;
    }

    // 6. /feito [categoria] [atividade] [quantidade]
    if (cleanCmd.startsWith('/feito')) {
      const partes = cleanCmd.replace('/feito', '').trim().split(' ');

      if (partes.length >= 3) {
        const cat = partes[0].toLowerCase();
        const qtdStr = partes[partes.length - 1];
        const ativ = partes.slice(1, partes.length - 1).join(' ');
        const valor = parseFloat(qtdStr.replace(',', '.'));

        if (isNaN(valor)) {
          setTimeout(() => {
            addBotMessage(`⚠️ A quantidade deve ser um número! Ex: \`/feito corrida Parque 5\``);
          }, 300);
          return;
        }

        if (onRegistrarFeito) {
          onRegistrarFeito(cat, ativ, valor);
        }

        setTimeout(() => {
          addBotMessage(
            `✅ *Lançamento concluído com sucesso!*\n\n` +
              `📁 *Categoria:* ${cat}\n` +
              `📌 *Atividade:* ${ativ}\n` +
              `➕ *Registrado:* \`+${valor}\`\n` +
              `📊 *Meta da Categoria:* Atualizada!\n\n` +
              `_O Score Geral e os Dashboards mensais/anuais foram atualizados!_`
          );
        }, 300);
        return;
      }

      // Se enviou /feito sozinho
      setTimeout(() => {
        addBotMessage(
          `📋 *O que você realizou?*\n\n` +
            `Envie no formato direto:\n` +
            `\`/feito [categoria] [atividade] [quantidade]\`\n\n` +
            `*Exemplos práticos:*\n` +
            `• \`/feito corrida Parque 5\` (5 km no Parque)\n` +
            `• \`/feito corrida Esteira 4\` (4 km na Esteira)\n` +
            `• \`/feito leitura Habitos 25\` (25 páginas no Hábitos Atômicos)\n` +
            `• \`/feito trabalho Empresa 8\` (8 horas na Empresa)`
        );
      }, 300);
      return;
    }

    // Comando não reconhecido
    setTimeout(() => {
      addBotMessage(
        `❓ Comando não reconhecido.\n` +
          `Experimente digitar:\n` +
          `• \`/feito corrida Parque 5\`\n` +
          `• \`/nova_atividade Esteira\`\n` +
          `• \`/agendar 14:30 Dentista\`\n` +
          `• \`/score\` ou \`/agenda\``
      );
    }, 300);
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim()) return;
    const txt = inputVal;
    setInputVal('');
    handleCommand(txt);
  };

  return (
    <div className="max-w-3xl mx-auto bg-[#0d0d0d] rounded-2xl border border-[#222] overflow-hidden flex flex-col h-[650px] shadow-sm">
      {/* Top Header */}
      <div className="bg-[#121212] border-b border-[#222] p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-blue-500/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
            <Bot className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-white text-sm">Duckao Bot (Telegram)</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            </div>
            <span className="text-[11px] text-[#777] font-mono">@duckao_rotina_bot • Firestore</span>
          </div>
        </div>

        <button
          onClick={() =>
            setMessages([
              {
                id: 'm1',
                sender: 'bot',
                text: `👋 *Sistema de Gestão de Rotina & Metas*\n\nExperimente: \`/feito corrida Parque 5\` ou \`/nova_atividade Parque\``,
                time: '12:00'
              }
            ])
          }
          className="text-xs text-[#777] hover:text-white flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#181818] border border-[#2a2a2a]"
        >
          <RotateCcw className="w-3 h-3" /> Limpar Chat
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4 no-scrollbar bg-[#080808]">
        {messages.map((m) => {
          const isBot = m.sender === 'bot';
          return (
            <div key={m.id} className={`flex flex-col ${isBot ? 'items-start' : 'items-end'}`}>
              <div
                className={`max-w-[85%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed ${
                  isBot
                    ? 'bg-[#141414] border border-[#262626] text-[#e0e0e0] rounded-tl-none'
                    : 'bg-amber-500 text-black font-medium rounded-tr-none shadow-xs'
                }`}
              >
                <div className="whitespace-pre-line">{m.text}</div>

                {/* Inline Buttons do Bot */}
                {m.buttons && m.buttons.length > 0 && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-3 pt-3 border-t border-[#262626]">
                    {m.buttons.map((btn, idx) => (
                      <button
                        key={idx}
                        onClick={btn.action}
                        className="w-full text-left px-3 py-2 rounded-lg bg-[#1a1a1a] hover:bg-[#252525] border border-[#333] text-amber-300 font-medium text-xs transition-all flex items-center justify-between"
                      >
                        <span>{btn.label}</span>
                        <Sparkles className="w-3 h-3 text-amber-400 opacity-60" />
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <span className="text-[10px] text-[#555] mt-1 px-1 font-mono">{m.time}</span>
            </div>
          );
        })}
        <div ref={chatEndRef} />
      </div>

      {/* Input Bar */}
      <form onSubmit={handleSend} className="p-3 bg-[#111] border-t border-[#222] flex items-center gap-2">
        <input
          type="text"
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          placeholder="Ex: /feito corrida Parque 5 ou /agendar 14:30 Dentista"
          className="flex-1 bg-[#181818] border border-[#2a2a2a] rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white placeholder-[#555] outline-hidden focus:border-amber-500/50 transition-all font-mono"
        />
        <button
          type="submit"
          className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-black font-semibold rounded-xl text-xs flex items-center gap-1.5 transition-all cursor-pointer"
        >
          <Send className="w-3.5 h-3.5" />
          <span>Enviar</span>
        </button>
      </form>
    </div>
  );
};
