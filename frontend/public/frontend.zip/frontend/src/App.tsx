import React, { useState, useEffect } from 'react';
import { Navbar, AppTab } from './components/Navbar';
import { CalendarView } from './components/CalendarView';
import { AtividadesView } from './components/AtividadesView';
import { TelegramSimulator } from './components/TelegramSimulator';
import { MetasScoreView } from './components/MetasScoreView';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { CodeViewer } from './components/CodeViewer';
import {
  CATEGORIAS_INICIAIS,
  ATIVIDADES_INICIAIS,
  AGENDAMENTOS_INICIAIS,
  METAS_MENSAIS_INICIAIS as METAS_INICIAIS,
  REGISTROS_MENSAIS_2026
} from './data/initialData';
import {
  Categoria,
  AtividadeCadastrada,
  AgendamentoItem,
  MetaCategoria,
  RegistroMensalCategoria
} from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<AppTab>('analytics');

  // Categorias persistidas
  const [categorias, setCategorias] = useState<Categoria[]>(() => {
    const saved = localStorage.getItem('rotina_categorias');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return CATEGORIAS_INICIAIS;
  });

  // Atividades persistidas
  const [atividades, setAtividades] = useState<AtividadeCadastrada[]>(() => {
    const saved = localStorage.getItem('rotina_atividades');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return ATIVIDADES_INICIAIS;
  });

  // Agendamentos persistidos
  const [agendamentos, setAgendamentos] = useState<AgendamentoItem[]>(() => {
    const saved = localStorage.getItem('rotina_agendamentos');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return AGENDAMENTOS_INICIAIS;
  });

  // Metas persistidas
  const [metas, setMetas] = useState<MetaCategoria[]>(() => {
    const saved = localStorage.getItem('rotina_metas');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return METAS_INICIAIS;
  });

  // Registros mensais para análises (Jan a Set 2026)
  const [registrosMensais, setRegistrosMensais] = useState<RegistroMensalCategoria[]>(() => {
    const saved = localStorage.getItem('rotina_registros_mensais');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return REGISTROS_MENSAIS_2026;
  });

  // Persistências no localStorage
  useEffect(() => {
    localStorage.setItem('rotina_categorias', JSON.stringify(categorias));
  }, [categorias]);

  useEffect(() => {
    localStorage.setItem('rotina_atividades', JSON.stringify(atividades));
  }, [atividades]);

  useEffect(() => {
    localStorage.setItem('rotina_agendamentos', JSON.stringify(agendamentos));
  }, [agendamentos]);

  useEffect(() => {
    localStorage.setItem('rotina_metas', JSON.stringify(metas));
  }, [metas]);

  useEffect(() => {
    localStorage.setItem('rotina_registros_mensais', JSON.stringify(registrosMensais));
  }, [registrosMensais]);

  // Handlers para Atividades e Categorias
  const handleAddAtividade = (nova: Omit<AtividadeCadastrada, 'id' | 'criado_em'>): string => {
    const id = `ativ_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 6)}`;
    const fullAtividade: AtividadeCadastrada = {
      ...nova,
      id,
      criado_em: new Date().toISOString()
    };
    setAtividades((prev) => [fullAtividade, ...prev]);
    return id;
  };

  const handleAddCategoria = (nova: Omit<Categoria, 'id' | 'criado_em'>): string => {
    const id = `cat_${nova.nome.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${Date.now().toString(36).substring(4)}`;
    const fullCat: Categoria = {
      ...nova,
      id,
      criado_em: new Date().toISOString()
    };
    setCategorias((prev) => [...prev, fullCat]);

    // Cria meta correspondente com valores padrão
    const novaMeta: MetaCategoria = {
      id: `meta_${id}`,
      categoria_id: id,
      categoria_nome: nova.nome,
      periodo: 'mensal',
      niveis: {
        minimo: 10,
        ideal: 20,
        excepcional: 30
      },
      progresso_mes_atual: 0,
      unidade: nova.unidade_padrao
    };
    setMetas((prev) => [...prev, novaMeta]);

    return id;
  };

  const handleDeleteAtividade = (id: string) => {
    setAtividades((prev) => prev.filter((a) => a.id !== id));
  };

  // Handlers para Agendamento
  const handleAddAgendamento = (item: Omit<AgendamentoItem, 'id'>) => {
    const id = `ag_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 6)}`;
    const novo: AgendamentoItem = {
      ...item,
      id
    };
    setAgendamentos((prev) => [novo, ...prev]);
  };

  const handleToggleConcluido = (id: string) => {
    setAgendamentos((prev) =>
      prev.map((it) => (it.id === id ? { ...it, concluido: !it.concluido } : it))
    );
  };

  const handleDeleteAgendamento = (id: string) => {
    setAgendamentos((prev) => prev.filter((it) => it.id !== id));
  };

  // Registro de /feito oriundo do simulador Telegram ou de lançamentos rápidos
  const handleRegistrarFeito = (catNomeOrId: string, ativNome: string, valor: number) => {
    const cleanCat = catNomeOrId.toLowerCase();
    const catEncontrada = categorias.find(
      (c) =>
        c.id.toLowerCase() === cleanCat ||
        c.nome.toLowerCase().includes(cleanCat)
    );

    if (!catEncontrada) return;

    // 1. Atualizar o progresso da meta do mês atual
    setMetas((prev) =>
      prev.map((m) =>
        m.categoria_id === catEncontrada.id
          ? { ...m, progresso_mes_atual: m.progresso_mes_atual + valor }
          : m
      )
    );

    // 2. Atualizar progresso acumulado da atividade específica
    setAtividades((prev) =>
      prev.map((a) => {
        if (
          a.categoria_id === catEncontrada.id &&
          a.nome.toLowerCase().includes(ativNome.toLowerCase())
        ) {
          return {
            ...a,
            progresso_acumulado_ano: (a.progresso_acumulado_ano || 0) + valor
          };
        }
        return a;
      })
    );

    // 3. Atualizar o registro mensal de Setembro 2026
    setRegistrosMensais((prev) => {
      const existe = prev.find(
        (r) => r.ano === 2026 && r.mes === 9 && r.categoria_id === catEncontrada.id
      );

      if (existe) {
        const breakdown = { ...(existe.atividades_breakdown || {}) };
        breakdown[ativNome] = (breakdown[ativNome] || 0) + valor;

        return prev.map((r) =>
          r.ano === 2026 && r.mes === 9 && r.categoria_id === catEncontrada.id
            ? {
                ...r,
                valor_total: r.valor_total + valor,
                atividades_breakdown: breakdown
              }
            : r
        );
      } else {
        const novoReg: RegistroMensalCategoria = {
          id: `reg_2026_09_${catEncontrada.id}`,
          ano: 2026,
          mes: 9,
          categoria_id: catEncontrada.id,
          categoria_nome: catEncontrada.nome,
          valor_total: valor,
          unidade: catEncontrada.unidade_padrao,
          atividades_breakdown: { [ativNome]: valor }
        };
        return [...prev, novoReg];
      }
    });
  };

  // Cálculo do Score Geral para a barra superior
  let somaScoreGeral = 0;
  let somaPesos = 0;
  metas.forEach((m) => {
    const cat = categorias.find((c) => c.id === m.categoria_id);
    const peso = cat?.peso_no_score || 0;
    if (peso > 0) {
      const { minimo, ideal, excepcional } = m.niveis;
      const atual = m.progresso_mes_atual;
      let scoreInd = 0;
      if (atual > 0) {
        if (atual < minimo) scoreInd = Math.round((atual / minimo) * 60);
        else if (atual <= ideal) scoreInd = 100;
        else scoreInd = 100 + Math.min(20, Math.round(((atual - ideal) / Math.max(1, excepcional - ideal)) * 20));
      }
      somaScoreGeral += scoreInd * peso;
      somaPesos += peso;
    }
  });
  const scoreGeralCalculado = somaPesos > 0 ? Math.round(somaScoreGeral / somaPesos) : 0;

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#d4d4d4] flex flex-col font-sans antialiased selection:bg-amber-500/30 selection:text-amber-200">
      {/* Header Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        categoriesCount={categorias.length}
        activitiesCount={atividades.length}
        scoreGeral={scoreGeralCalculado}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'analytics' && (
          <AnalyticsDashboard
            categorias={categorias}
            atividades={atividades}
            metas={metas}
            registrosMensais={registrosMensais}
          />
        )}

        {activeTab === 'calendario' && (
          <CalendarView
            agendamentos={agendamentos}
            atividades={atividades}
            categorias={categorias}
            onAddAgendamento={handleAddAgendamento}
            onToggleConcluido={handleToggleConcluido}
            onDeleteAgendamento={handleDeleteAgendamento}
            onSyncGoogleCalendar={() => {}}
          />
        )}

        {activeTab === 'atividades' && (
          <AtividadesView
            categorias={categorias}
            atividades={atividades}
            onAddAtividade={(nova) => handleAddAtividade(nova)}
            onAddCategoria={(nova) => handleAddCategoria(nova)}
            onDeleteAtividade={handleDeleteAtividade}
          />
        )}

        {activeTab === 'metas' && (
          <MetasScoreView
            categorias={categorias}
            metas={metas}
            onUpdateCategorias={setCategorias}
            onUpdateMetas={setMetas}
          />
        )}

        {activeTab === 'simulador' && (
          <TelegramSimulator
            categorias={categorias}
            atividades={atividades}
            onAddAtividadeFromBot={(nova) => handleAddAtividade(nova)}
            onAddCategoriaFromBot={(nome, unidade, peso) =>
              handleAddCategoria({
                nome,
                unidade_padrao: unidade,
                peso_no_score: peso,
                cor: '#3B82F6',
                icone: 'Folder'
              })
            }
            onRegistrarFeito={handleRegistrarFeito}
            onAgendarPontual={(hora, titulo) =>
              handleAddAgendamento({
                tipo: 'pontual',
                titulo,
                data: '2026-09-07',
                hora_inicio: hora,
                concluido: false
              })
            }
          />
        )}

        {activeTab === 'codigo' && <CodeViewer />}
      </main>

      {/* Footer */}
      <footer className="border-t border-[#222] bg-[#0d0d0d] py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-[#777] gap-2">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
            <span className="text-[#888]">
              Gestão de Rotina & Metas <span className="text-[#444]">•</span> Granularidade Mensal & Acumulados Gerais (2026)
            </span>
          </div>
          <div className="flex items-center gap-3 font-mono text-[11px] text-[#666]">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              Pilar Trabalho com Peso 0 (Horas Rastreadas)
            </span>
            <span className="text-[#333]">•</span>
            <span className="text-amber-400/80">Firestore DocumentReference</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
